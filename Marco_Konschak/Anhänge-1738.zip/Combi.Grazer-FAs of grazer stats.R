require(vegan)
require(multcomp)
require(car)
require(data.table)
require(asbio)
require(plotrix)

Snail<-data.table(read.table("2019-10-27-Grazer-FAs of snails.txt"))
Snail[, Name := as.character(Name)]
Snail[, RUNINFO := as.character(RUNINFO)]
Snail[, Treatment := as.factor(Treatment)]
Snail[, Replicate := as.character(Replicate)]
Snail[, FA_mass := as.numeric(FA_mass)]
Snail[, �g_FA_per_mg := as.numeric(�g_FA_per_mg)]

Snail<-Snail[order(Treatment),]
Snail[,Name := gsub(" ", "", Name)]

Names<-unique(Snail$Name)
Names
RUNINFOs<-Snail$RUNINFO[Snail$Name=="16:0"]
Treatments<-Snail$Treatment[Snail$Name=="16:0"]
Replicates<-Snail$Replicate[Snail$Name=="16:0"]

`C12:0`    <-Snail$�g_FA_per_mg[Snail$Name=="12:0"]
`C14:0`    <-Snail$�g_FA_per_mg[Snail$Name=="14:0"]
`C15:0`    <-Snail$�g_FA_per_mg[Snail$Name=="15:0"]
`C16:0`    <-Snail$�g_FA_per_mg[Snail$Name=="16:0"]
`C16:1n-7` <-Snail$�g_FA_per_mg[Snail$Name=="16:1n-7"]
`C17:0`    <-Snail$�g_FA_per_mg[Snail$Name=="17:0"]
`C18:0`    <-Snail$�g_FA_per_mg[Snail$Name=="18:0"]
`C18:1n-7` <-Snail$�g_FA_per_mg[Snail$Name=="18:1n-7"]
`C18:1n-9c`<-Snail$�g_FA_per_mg[Snail$Name=="18:1n-9c"]
`C18:2n-6c`<-Snail$�g_FA_per_mg[Snail$Name=="18:2n-6c"]
`C18:3n-3` <-Snail$�g_FA_per_mg[Snail$Name=="18:3n-3"]
`C18:3n-6` <-Snail$�g_FA_per_mg[Snail$Name=="18:3n-6"]
`C20:0`    <-Snail$�g_FA_per_mg[Snail$Name=="20:0"]
`C20:1n-9` <-Snail$�g_FA_per_mg[Snail$Name=="20:1n-9"]
`C20:2n-6` <-Snail$�g_FA_per_mg[Snail$Name=="20:2n-6"]
`C20:3n-3` <-Snail$�g_FA_per_mg[Snail$Name=="20:3n-3"]
`C20:3n-6` <-Snail$�g_FA_per_mg[Snail$Name=="20:3n-6"]
`C20:4n-6` <-Snail$�g_FA_per_mg[Snail$Name=="20:4n-6"]
`C20:5n-3` <-Snail$�g_FA_per_mg[Snail$Name=="20:5n-3"]
`C22:0`    <-Snail$�g_FA_per_mg[Snail$Name=="22:0"]
`C22:1n-9` <-Snail$�g_FA_per_mg[Snail$Name=="22:1n-9"]
`C22:6n-3` <-Snail$�g_FA_per_mg[Snail$Name=="22:6n-3"]
`C23:0`    <-Snail$�g_FA_per_mg[Snail$Name=="23:0"]
`C24:0`    <-Snail$�g_FA_per_mg[Snail$Name=="24:0"]

Snail2<-data.table(data.frame(Treatment=Treatments,Replicate=Replicates,`C12:0`=`C12:0`,`C14:0`=`C14:0`,
                              `C15:0`=`C15:0`,`C16:0`=`C16:0`,`C16:1n-7`=`C16:1n-7`,`C17:0`=`C17:0`,
                              `C18:0`=`C18:0`,`C18:1n-7`=`C18:1n-7`,`C18:1n-9c`=`C18:1n-9c`,
                              `C18:2n-6c`=`C18:2n-6c`,`C18:3n-3`=`C18:3n-3`,`C18:3n-6`=`C18:3n-6`,
                              `C20:0`=`C20:0`,`C20:1n-9`=`C20:1n-9`,`C20:2n-6`=`C20:2n-6`,
                              `C20:3n-3`=`C20:3n-3`,`C20:3n-6`=`C20:3n-6`,`C20:4n-6`=`C20:4n-6`,
                              `C20:5n-3`=`C20:5n-3`,`C22:0`=`C22:0`,`C22:1n-9`=`C22:1n-9`,
                              `C22:6n-3`=`C22:6n-3`,`C23:0`=`C23:0`,`C24:0`=`C24:0`))

Snail2_ohneTR<-Snail2[,c(-1,-2)]


`X_C12:0`    <-Snail$FA_mass[Snail$Name=="12:0"]
`X_C14:0`    <-Snail$FA_mass[Snail$Name=="14:0"]
`X_C15:0`    <-Snail$FA_mass[Snail$Name=="15:0"]
`X_C16:0`    <-Snail$FA_mass[Snail$Name=="16:0"]
`X_C16:1n-7` <-Snail$FA_mass[Snail$Name=="16:1n-7"]
`X_C17:0`    <-Snail$FA_mass[Snail$Name=="17:0"]
`X_C18:0`    <-Snail$FA_mass[Snail$Name=="18:0"]
`X_C18:1n-7` <-Snail$FA_mass[Snail$Name=="18:1n-7"]
`X_C18:1n-9c`<-Snail$FA_mass[Snail$Name=="18:1n-9c"]
`X_C18:2n-6c`<-Snail$FA_mass[Snail$Name=="18:2n-6c"]
`X_C18:3n-3` <-Snail$FA_mass[Snail$Name=="18:3n-3"]
`X_C18:3n-6` <-Snail$FA_mass[Snail$Name=="18:3n-6"]
`X_C20:0`    <-Snail$FA_mass[Snail$Name=="20:0"]
`X_C20:1n-9` <-Snail$FA_mass[Snail$Name=="20:1n-9"]
`X_C20:2n-6` <-Snail$FA_mass[Snail$Name=="20:2n-6"]
`X_C20:3n-3` <-Snail$FA_mass[Snail$Name=="20:3n-3"]
`X_C20:3n-6` <-Snail$FA_mass[Snail$Name=="20:3n-6"]
`X_C20:4n-6` <-Snail$FA_mass[Snail$Name=="20:4n-6"]
`X_C20:5n-3` <-Snail$FA_mass[Snail$Name=="20:5n-3"]
`X_C22:0`    <-Snail$FA_mass[Snail$Name=="22:0"]
`X_C22:1n-9` <-Snail$FA_mass[Snail$Name=="22:1n-9"]
`X_C22:6n-3` <-Snail$FA_mass[Snail$Name=="22:6n-3"]
`X_C23:0`    <-Snail$FA_mass[Snail$Name=="23:0"]
`X_C24:0`    <-Snail$FA_mass[Snail$Name=="24:0"]


total_FAs<-data.table(data.frame(Treatment=Treatments,Replicate=Replicates,`C12:0`=`X_C12:0`,`C14:0`=`X_C14:0`,
                                 `C15:0`=`X_C15:0`,`C16:0`=`X_C16:0`,`C16:1n-7`=`X_C16:1n-7`,`C17:0`=`X_C17:0`,
                                 `C18:0`=`X_C18:0`,`C18:1n-7`=`X_C18:1n-7`,`C18:1n-9c`=`X_C18:1n-9c`,
                                 `C18:2n-6c`=`X_C18:2n-6c`,`C18:3n-3`=`X_C18:3n-3`,`C18:3n-6`=`X_C18:3n-6`,
                                 `C20:0`=`X_C20:0`,`C20:1n-9`=`X_C20:1n-9`,`C20:2n-6`=`X_C20:2n-6`,
                                 `C20:3n-3`=`X_C20:3n-3`,`C20:3n-6`=`X_C20:3n-6`,`C20:4n-6`=`X_C20:4n-6`,
                                 `C20:5n-3`=`X_C20:5n-3`,`C22:0`=`X_C22:0`,`C22:1n-9`=`X_C22:1n-9`,
                                 `C22:6n-3`=`X_C22:6n-3`,`C23:0`=`X_C23:0`,`C24:0`=`X_C24:0`))


###relativ
total_FAs_ohneTR<-total_FAs[,c(-1,-2)]
total_FAs_rel_ohneTR<-total_FAs_ohneTR/rowSums(total_FAs_ohneTR)*100
rowSums(total_FAs_rel_ohneTR)
total_FAs_rel<-cbind(total_FAs[,c(1,2)],total_FAs_rel_ohneTR)

# SAFA

m_C12.0<-tapply(total_FAs_rel$C12.0,total_FAs_rel$Treatment,median)
m_C12.0<-m_C12.0[!is.na(m_C12.0)]
lower_C12.0<-tapply(total_FAs_rel$C12.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C12.0<-lower_C12.0[!is.na(lower_C12.0)]
upper_C12.0<-tapply(total_FAs_rel$C12.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C12.0<-upper_C12.0[!is.na(upper_C12.0)]

m_C14.0<-tapply(total_FAs_rel$C14.0,total_FAs_rel$Treatment,median)
m_C14.0<-m_C14.0[!is.na(m_C14.0)]
lower_C14.0<-tapply(total_FAs_rel$C14.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C14.0<-lower_C14.0[!is.na(lower_C14.0)]
upper_C14.0<-tapply(total_FAs_rel$C14.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C14.0<-upper_C14.0[!is.na(upper_C14.0)]

m_C15.0<-tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,median)
m_C15.0<-m_C15.0[!is.na(m_C15.0)]
lower_C15.0<-tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C15.0<-lower_C15.0[!is.na(lower_C15.0)]
upper_C15.0<-tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C15.0<-upper_C15.0[!is.na(upper_C15.0)]

m_C16.0<-tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,median)
m_C16.0 <- m_C16.0[!is.na(m_C16.0)]
lower_C16.0<-tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C16.0<-lower_C16.0[!is.na(lower_C16.0)]
upper_C16.0<-tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C16.0<-upper_C16.0[!is.na(upper_C16.0)]

m_C17.0<-tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,median)
m_C17.0 <- m_C17.0[!is.na(m_C17.0)]
lower_C17.0<-tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C17.0<-lower_C17.0[!is.na(lower_C17.0)]
upper_C17.0<-tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C17.0<-upper_C17.0[!is.na(upper_C17.0)]

m_C18.0<-tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,median)
m_C18.0<-m_C18.0[!is.na(m_C18.0)]
lower_C18.0<-tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.0<-lower_C18.0[!is.na(lower_C18.0)]
upper_C18.0<-tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.0<-upper_C18.0[!is.na(upper_C18.0)]

m_C20.0<-tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,median)
m_C20.0<-m_C20.0[!is.na(m_C20.0)]
lower_C20.0<-tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.0<-lower_C20.0[!is.na(lower_C20.0)]
upper_C20.0<-tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.0<-upper_C20.0[!is.na(upper_C20.0)]

m_C22.0<-tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,median)
m_C22.0<-m_C22.0[!is.na(m_C22.0)]
lower_C22.0<-tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C22.0<-lower_C22.0[!is.na(lower_C22.0)]
upper_C22.0<-tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C22.0<-upper_C22.0[!is.na(upper_C22.0)]

m_C23.0<-tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,median)
m_C23.0<-m_C23.0[!is.na(m_C23.0)]
lower_C23.0<-tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C23.0<-lower_C23.0[!is.na(lower_C23.0)]
upper_C23.0<-tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C23.0<-upper_C23.0[!is.na(upper_C23.0)]

m_C24.0<-tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,median)
m_C24.0<-m_C24.0[!is.na(m_C24.0)]
lower_C24.0<-tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C24.0<-lower_C24.0[!is.na(lower_C24.0)]
upper_C24.0<-tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C24.0<-upper_C24.0[!is.na(upper_C24.0)]

# MUFA

m_C16.1n.7<-tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,median)
m_C16.1n.7 <- m_C16.1n.7[!is.na(m_C16.1n.7)]
lower_C16.1n.7<-tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C16.1n.7<-lower_C16.1n.7[!is.na(lower_C16.1n.7)]
upper_C16.1n.7<-tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C16.1n.7<-upper_C16.1n.7[!is.na(upper_C16.1n.7)]

m_C18.1n.7<-tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,median)
m_C18.1n.7 <- m_C18.1n.7[!is.na(m_C18.1n.7)]
lower_C18.1n.7<-tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.1n.7<-lower_C18.1n.7[!is.na(lower_C18.1n.7)]
upper_C18.1n.7<-tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.1n.7<-upper_C18.1n.7[!is.na(upper_C18.1n.7)]

m_C18.1n.9c<-tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,median)
m_C18.1n.9c<-m_C18.1n.9c[!is.na(m_C18.1n.9c)]
lower_C18.1n.9c<-tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.1n.9c<-lower_C18.1n.9c[!is.na(lower_C18.1n.9c)]
upper_C18.1n.9c<-tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.1n.9c<-upper_C18.1n.9c[!is.na(upper_C18.1n.9c)]

m_C20.1n.9<-tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,median)
m_C20.1n.9<-m_C20.1n.9[!is.na(m_C20.1n.9)]
lower_C20.1n.9<-tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.1n.9<-lower_C20.1n.9[!is.na(lower_C20.1n.9)]
upper_C20.1n.9<-tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.1n.9<-upper_C20.1n.9[!is.na(upper_C20.1n.9)]

m_C22.1n.9<-tapply(total_FAs_rel$C22.1n.9,total_FAs_rel$Treatment,median)
m_C22.1n.9<-m_C22.1n.9[!is.na(m_C22.1n.9)]
lower_C22.1n.9<-tapply(total_FAs_rel$C22.1n.9,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C22.1n.9<-lower_C22.1n.9[!is.na(lower_C22.1n.9)]
upper_C22.1n.9<-tapply(total_FAs_rel$C22.1n.9,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C22.1n.9<-upper_C22.1n.9[!is.na(upper_C22.1n.9)]

# PUFA

m_C18.2n.6c<-tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,median)
m_C18.2n.6c<-m_C18.2n.6c[!is.na(m_C18.2n.6c)]
lower_C18.2n.6c<-tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.2n.6c<-lower_C18.2n.6c[!is.na(lower_C18.2n.6c)]
upper_C18.2n.6c<-tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.2n.6c<-upper_C18.2n.6c[!is.na(upper_C18.2n.6c)]

m_C18.3n.3<-tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,median)
m_C18.3n.3<-m_C18.3n.3[!is.na(m_C18.3n.3)]
lower_C18.3n.3<-tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.3n.3<-lower_C18.3n.3[!is.na(lower_C18.3n.3)]
upper_C18.3n.3<-tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.3n.3<-upper_C18.3n.3[!is.na(upper_C18.3n.3)]

m_C18.3n.6<-tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,median)
m_C18.3n.6<-m_C18.3n.6[!is.na(m_C18.3n.6)]
lower_C18.3n.6<-tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.3n.6<-lower_C18.3n.6[!is.na(lower_C18.3n.6)]
upper_C18.3n.6<-tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.3n.6<-upper_C18.3n.6[!is.na(upper_C18.3n.6)]

m_C20.2n.6<-tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,median)
m_C20.2n.6<-m_C20.2n.6[!is.na(m_C20.2n.6)]
lower_C20.2n.6<-tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.2n.6<-lower_C20.2n.6[!is.na(lower_C20.2n.6)]
upper_C20.2n.6<-tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.2n.6<-upper_C20.2n.6[!is.na(upper_C20.2n.6)]

m_C20.3n.3<-tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,median)
m_C20.3n.3<-m_C20.3n.3[!is.na(m_C20.3n.3)]
lower_C20.3n.3<-tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.3n.3<-lower_C20.3n.3[!is.na(lower_C20.3n.3)]
upper_C20.3n.3<-tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.3n.3<-upper_C20.3n.3[!is.na(upper_C20.3n.3)]

m_C20.3n.6<-tapply(total_FAs_rel$C20.3n.6,total_FAs_rel$Treatment,median)
m_C20.3n.6<-m_C20.3n.6[!is.na(m_C20.3n.6)]
lower_C20.3n.6<-tapply(total_FAs_rel$C20.3n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.3n.6<-lower_C20.3n.6[!is.na(lower_C20.3n.6)]
upper_C20.3n.6<-tapply(total_FAs_rel$C20.3n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.3n.6<-upper_C20.3n.6[!is.na(upper_C20.3n.6)]

m_C20.4n.6<-tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,median)
m_C20.4n.6<-m_C20.4n.6[!is.na(m_C20.4n.6)]
lower_C20.4n.6<-tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.4n.6<-lower_C20.4n.6[!is.na(lower_C20.4n.6)]
upper_C20.4n.6<-tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.4n.6<-upper_C20.4n.6[!is.na(upper_C20.4n.6)]

m_C20.5n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,median)
m_C20.5n.3<-m_C20.5n.3[!is.na(m_C20.5n.3)]
lower_C20.5n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.5n.3<-lower_C20.5n.3[!is.na(lower_C20.5n.3)]
upper_C20.5n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.5n.3<-upper_C20.5n.3[!is.na(upper_C20.5n.3)]

m_C22.6n.3<-tapply(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment,median)
m_C22.6n.3<-m_C22.6n.3[!is.na(m_C22.6n.3)]
lower_C22.6n.3<-tapply(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C22.6n.3<-lower_C22.6n.3[!is.na(lower_C22.6n.3)]
upper_C22.6n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C22.6n.3<-upper_C22.6n.3[!is.na(upper_C22.6n.3)]

m_sat<-c(m_C12.0,m_C14.0,m_C15.0,m_C16.0,m_C17.0,m_C18.0,m_C20.0,m_C22.0,m_C23.0,m_C24.0)
m_mono<-c(m_C16.1n.7,m_C18.1n.7,m_C18.1n.9c,m_C20.1n.9,m_C22.1n.9)
m_poly<-c(m_C18.2n.6c,m_C18.3n.3,m_C18.3n.6,m_C20.2n.6,m_C20.3n.3,m_C20.3n.6,m_C20.4n.6,m_C20.5n.3,m_C22.6n.3)

lower_sat<-c(lower_C12.0,lower_C14.0,lower_C15.0,lower_C16.0,lower_C17.0,lower_C18.0,lower_C20.0,lower_C22.0,lower_C23.0,lower_C24.0)
lower_mono<-c(lower_C16.1n.7,lower_C18.1n.7,lower_C18.1n.9c,lower_C20.1n.9,lower_C22.1n.9)
lower_poly<-c(lower_C18.2n.6c,lower_C18.3n.3,lower_C18.3n.6,lower_C20.2n.6,lower_C20.3n.3,lower_C20.3n.6,lower_C20.4n.6,lower_C20.5n.3,lower_C22.6n.3)

upper_sat<-c(upper_C12.0,upper_C14.0,upper_C15.0,upper_C16.0,upper_C17.0,upper_C18.0,upper_C20.0,upper_C22.0,upper_C23.0,upper_C24.0)
upper_mono<-c(upper_C16.1n.7,upper_C18.1n.7,upper_C18.1n.9c,upper_C20.1n.9,upper_C22.1n.9)
upper_poly<-c(upper_C18.2n.6c,upper_C18.3n.3,upper_C18.3n.6,upper_C20.2n.6,upper_C20.3n.3,upper_C20.3n.6,upper_C20.4n.6,upper_C20.5n.3,upper_C22.6n.3)

m_all<-c(m_sat,m_mono,m_poly)
lower_all<-c(lower_sat,lower_mono,lower_poly)
upper_all<-c(upper_sat,upper_mono,upper_poly)

SAFA_cumulative<-data.table(data.frame(FA=c(rep("12:0",times=2),rep("14:0",times=2),rep("15:0",times=2),rep("16:0",times=2),rep("17:0",times=2),rep("18:0",times=2),
                                            rep("20:0",times=2),rep("22:0",times=2),rep("23:0",times=2),rep("24:0",times=2)),
                                       Treatment=rep(c("C","T"),times=10),mSAFA=m_sat,lSAFA=lower_sat,uSAFA=upper_sat))
tapply(SAFA_cumulative$mSAFA,SAFA_cumulative$Treatment,sum)
tapply(SAFA_cumulative$lSAFA,SAFA_cumulative$Treatment,sum)
tapply(SAFA_cumulative$uSAFA,SAFA_cumulative$Treatment,sum)

MUFA_cumulative<-data.table(data.frame(FA=c(rep("16:1n-7",times=2),rep("18:1n-7",times=2),rep("18:1n-9",times=2),rep("20:1n-9",times=2),rep("22:1n-9",times=2)),
                                       Treatment=rep(c("C","T"),times=5),mMUFA=m_mono,lMUFA=lower_mono,uMUFA=upper_mono))
tapply(MUFA_cumulative$mMUFA,MUFA_cumulative$Treatment,sum)
tapply(MUFA_cumulative$lMUFA,MUFA_cumulative$Treatment,sum)
tapply(MUFA_cumulative$uMUFA,MUFA_cumulative$Treatment,sum)

PUFA_cumulative<-data.table(data.frame(FA=c(rep("18:2n-6",times=2),rep("18:3n-3",times=2),rep("18:3n-6",times=2),rep("20:2n-6",times=2),rep("20:3n-3",times=2),rep("20:3n-6",times=2),rep("20:4n-6",times=2),rep("20:5n-3",times=2),rep("22:6n-3",times=2)),
                                       Treatment=rep(c("C","T"),times=9),mPUFA=m_poly,lPUFA=lower_poly,uPUFA=upper_poly))
tapply(PUFA_cumulative$mPUFA,PUFA_cumulative$Treatment,sum)
tapply(PUFA_cumulative$lPUFA,PUFA_cumulative$Treatment,sum)
tapply(PUFA_cumulative$uPUFA,PUFA_cumulative$Treatment,sum)


require(gplots)
par(mar=c(5, 4.5, 4, 2) + 0.1,xpd=FALSE)
barplot2(m_sat,space=c(1,0,1,0),xpd=FALSE,plot.ci=TRUE,ci.u=upper_sat,ci.l=lower_sat,ylim=c(0,25),
         las=1,yaxs="i",bty ="n",xaxt = "n",ylab=expression("Proportion of sat. FAs in %"),
         xlab=expression("Fatty acid"),col=c("white","red"),cex.axis=1.5,cex.lab=1.5,lwd=1.5,ci.lwd=1.5)
axis(1,at=c(2,5,8,11,14,17,20,23,26,29),labels=c("12:0","14:0","15:0","16:0","17:0","18:0","20:0","22:0","23:0","24:0"),tick=TRUE,cex.axis=1.5)
lines(c(-0.5,31),c(0,0),type="l",lty=1,lwd=1.5)

barplot2(m_mono,space=c(1,0,1,0),xpd=FALSE,plot.ci=TRUE,ci.u=upper_mono,ci.l=lower_mono,ylim=c(0,50),
         las=1,yaxs="i",bty ="n",xaxt = "n",ylab=expression("Proportion of monounsat. FAs in %"),
         xlab=expression("Fatty acid"),col=c("white","red"),cex.axis=1.5,cex.lab=1.5,lwd=1.5,ci.lwd=1.5)
axis(1,at=c(2,5,8,11,14),labels=c("16:1n-7","18:1n-7","18:1n-9","20:1n-9","22:1n-9"),tick=TRUE,cex.axis=1.5)
lines(c(0,21),c(0,0),type="l",lty=1,lwd=1.5)

barplot2(m_poly,space=c(1,0,1,0),xpd=FALSE,plot.ci=TRUE,ci.u=upper_poly,ci.l=lower_poly,ylim=c(0,45),
         las=1,yaxs="i",bty ="n",xaxt = "n",ylab=expression("Proportion of polyunsat. FAs in %"),
         xlab=expression("Fatty acid"),col=c("white","red"),cex.axis=1.5,cex.lab=1.5,lwd=1.5,ci.lwd=1.5)
axis(1,at=c(2,5,8,11,14,17,20,23,26),labels=c("18:2n-6","18:3n-3","18:3n-6","20:2n-6","20:3n-3","20:3n-6","20:4n-6","20:5n-3","22:6n-3"),tick=TRUE,cex.axis=1.5)
lines(c(-0.5,31),c(0,0),type="l",lty=1,lwd=1.5)

detach(package:gplots,unload=TRUE)


#### Table: relative FAs

MediansCIs<- data.frame(matrix(nrow = ncol(total_FAs_rel_ohneTR)*ncol(total_FAs_rel_ohneTR)+ncol(total_FAs_rel_ohneTR)+1, ncol = 6))
colnames(MediansCIs) <- c("Name","Treatment","Median", "lower CI","to","upper CI")
for(i in 1:ncol(total_FAs_rel_ohneTR))
{
  Medians  <-tapply(total_FAs_rel_ohneTR[[i]],total_FAs_rel$Treatment,median)
  CIs_lower<-tapply(total_FAs_rel_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[1])
  CIs_upper<-tapply(total_FAs_rel_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[2])

  MediansCIs[i*i+i, 1] <- Names[i]
  MediansCIs[i*i+i, 2] <- "Control"
  MediansCIs[i*i+i, 3] <- unname(Medians[!is.na(Medians)])[1]
  MediansCIs[i*i+i, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[1]
  MediansCIs[i*i+i, 5] <- "to"
  MediansCIs[i*i+i, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[1]

  MediansCIs[i*i+i+1, 1] <- Names[i]
  MediansCIs[i*i+i+1, 2] <- "Treatment"
  MediansCIs[i*i+i+1, 3] <- unname(Medians[!is.na(Medians)])[2]
  MediansCIs[i*i+i+1, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[2]
  MediansCIs[i*i+i+1, 5] <- "to"
  MediansCIs[i*i+i+1, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[2]

}

MediansCIs<-subset(MediansCIs,! Name %in% NA)
MediansCIs[,c(3,4,6)]<-round(MediansCIs[,c(3,4,6)],2)
MediansCIs$M_CIs<-with(MediansCIs, paste0(`Median`," ","(",`lower CI`," " ,`to`," " ,`upper CI`,")" ))
MediansCIs<-MediansCIs[,-c(3,4,5,6)]
MediansCIs_C<-subset(MediansCIs,! Treatment %in% "Treatment")
MediansCIs_T<-subset(MediansCIs,Treatment %in% "Treatment")
MediansCIs<-cbind(MediansCIs_C,MediansCIs_T)
MediansCIs<-MediansCIs[,-c(2,4,5)]
colnames(MediansCIs)[2] <- "Control"
colnames(MediansCIs)[3] <- "Diuron"
#write.table(MediansCIs, file = "Grazer study-relative FAs of grazer.txt", sep="\t")



#### Univariat RELATIV

# C12:0
tapply(total_FAs_rel$C12.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C12.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C12.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C12.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C12.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C12.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C14:0
tapply(total_FAs_rel$C14.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C14.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C14.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C14.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C14.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C14.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C15:0
tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C15.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C15.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C15.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C15.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C15.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C16:0
tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C16.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C16.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C16.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C16.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C16.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C17:0
tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C17.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C17.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C17.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C17.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C17.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)


# C18:0
tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C20:0
tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C20.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C22:0
tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C22.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C22.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C22.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C22.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C22.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C23:0
tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C23.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C23.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C23.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C23.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C23.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C24:0
tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C24.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C24.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C24.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C24.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C24.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C16:1n-7
tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="T"],total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:1n-7
tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:1n-9
tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:1n-9
tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C22:1n-9
tapply(total_FAs_rel$C22.1n.9,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C22.1n.9[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C22.1n.9[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C22.1n.9,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C22.1n.9[total_FAs_rel$Treatment=="T"],total_FAs_rel$C22.1n.9[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C18:2n-6c
tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:3n-3
tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:3n-6
tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C20:2n-6
tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# Tendenz

# C20:3n-3
tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C20:3n-6
tapply(total_FAs_rel$C20.3n.6,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.3n.6[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.3n.6[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.3n.6,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C20.3n.6[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.3n.6[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C20:4n-6
tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C20:5n-3
tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C22:6n-3
tapply(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# Tendenz

SAFA_sum<-subset(total_FAs_rel,select=c(C12.0,C14.0,C15.0,C16.0,C17.0,C18.0,C20.0,C22.0,C23.0,C24.0))
SAFA_sum<-rowSums(SAFA_sum)
SAFA_sum<-cbind(total_FAs_rel[,c(1,2)],SAFA_sum)

tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="C"])
qqPlot(SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(SAFA_sum$SAFA_sum,SAFA_sum$Treatment)

wilcox.test(SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="T"],SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.
medians_SAFA_sum<-tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,median)
lower_SAFA_sum<-tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_SAFA_sum<-tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,function(x) ci.median(x)$ci[3])

par(mar=c(5, 6.5, 2, 4) + 0.1,xpd=FALSE)
x<-c(1,2)
plotCI(x,medians_SAFA_sum,ui=upper_SAFA_sum,li=lower_SAFA_sum,ylim=c(0,40),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,10,20,30,40),labels=c(0,10,20,30,40),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Relative SAFA content in %",at=20,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)


MUFA_sum<-subset(total_FAs_rel,select=c(C16.1n.7,C18.1n.7,C18.1n.9c,C20.1n.9,C22.1n.9))
MUFA_sum<-rowSums(MUFA_sum)
MUFA_sum<-cbind(total_FAs_rel[,c(1,2)],MUFA_sum)

tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="C"])
qqPlot(MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(MUFA_sum$MUFA_sum,MUFA_sum$Treatment)

t.test(MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="T"],MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

medians_MUFA_sum<-tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,median)
lower_MUFA_sum<-tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_MUFA_sum<-tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_MUFA_sum,ui=upper_MUFA_sum,li=lower_MUFA_sum,ylim=c(0,50),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,10,20,30,40,50),labels=c(0,10,20,30,40,50),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Relative MUFA content in %",at=25,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

PUFA_sum<-subset(total_FAs_rel,select=c(C18.2n.6c,C18.3n.3,C18.3n.6,C20.2n.6,C20.3n.3,C20.3n.6,C20.4n.6,C20.5n.3,C22.6n.3))
PUFA_sum<-rowSums(PUFA_sum)
PUFA_sum<-cbind(total_FAs_rel[,c(1,2)],PUFA_sum)

tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="C"])
qqPlot(PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(PUFA_sum$PUFA_sum,PUFA_sum$Treatment)

t.test(PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="T"],PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

medians_PUFA_sum<-tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,median)
lower_PUFA_sum<-tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_PUFA_sum<-tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_PUFA_sum,ui=upper_PUFA_sum,li=lower_PUFA_sum,ylim=c(0,50),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,10,20,30,40,50),labels=c(0,10,20,30,40,50),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Relative PUFA content in %",at=25,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

#### Table: absolute FAs

MediansCIs<- data.frame(matrix(nrow = ncol(Snail2_ohneTR)*ncol(Snail2_ohneTR)+ncol(Snail2_ohneTR)+1, ncol = 6))
colnames(MediansCIs) <- c("Name","Treatment","Median", "lower CI","to","upper CI")
for(i in 1:ncol(Snail2_ohneTR))
{
  Medians  <-tapply(Snail2_ohneTR[[i]],total_FAs_rel$Treatment,median)
  CIs_lower<-tapply(Snail2_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[1])
  CIs_upper<-tapply(Snail2_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[2])

  MediansCIs[i*i+i, 1] <- Names[i]
  MediansCIs[i*i+i, 2] <- "Control"
  MediansCIs[i*i+i, 3] <- unname(Medians[!is.na(Medians)])[1]
  MediansCIs[i*i+i, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[1]
  MediansCIs[i*i+i, 5] <- "to"
  MediansCIs[i*i+i, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[1]

  MediansCIs[i*i+i+1, 1] <- Names[i]
  MediansCIs[i*i+i+1, 2] <- "Treatment"
  MediansCIs[i*i+i+1, 3] <- unname(Medians[!is.na(Medians)])[2]
  MediansCIs[i*i+i+1, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[2]
  MediansCIs[i*i+i+1, 5] <- "to"
  MediansCIs[i*i+i+1, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[2]

}

MediansCIs<-subset(MediansCIs,! Name %in% NA)
MediansCIs[,c(3,4,6)]<-round(MediansCIs[,c(3,4,6)],2)
MediansCIs$M_CIs<-with(MediansCIs, paste0(`Median`," ","(",`lower CI`," " ,`to`," " ,`upper CI`,")" ))
MediansCIs<-MediansCIs[,-c(3,4,5,6)]
MediansCIs_C<-subset(MediansCIs,! Treatment %in% "Treatment")
MediansCIs_T<-subset(MediansCIs,Treatment %in% "Treatment")
MediansCIs<-cbind(MediansCIs_C,MediansCIs_T)
MediansCIs<-MediansCIs[,-c(2,4,5)]
colnames(MediansCIs)[2] <- "Control"
colnames(MediansCIs)[3] <- "Diuron"
#write.table(MediansCIs, file = "Grazer study-total FAs of grazer.txt", sep="\t")


#### Univariat ABSOLUT

# C12:0
tapply(Snail2$C12.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C12.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C12.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C12.0,Snail2$Treatment)

t.test(Snail2$C12.0[Snail2$Treatment=="T"],Snail2$C12.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C14:0
tapply(Snail2$C14.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C14.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C14.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C14.0,Snail2$Treatment)

t.test(Snail2$C14.0[Snail2$Treatment=="T"],Snail2$C14.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C15:0
tapply(Snail2$C15.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C15.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C15.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C15.0,Snail2$Treatment)

wilcox.test(Snail2$C15.0[Snail2$Treatment=="T"],Snail2$C15.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig

# C16:0
tapply(Snail2$C16.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C16.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C16.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C16.0,Snail2$Treatment)

t.test(Snail2$C16.0[Snail2$Treatment=="T"],Snail2$C16.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C17:0
tapply(Snail2$C17.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C17.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C17.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C17.0,Snail2$Treatment)

t.test(Snail2$C17.0[Snail2$Treatment=="T"],Snail2$C17.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:0
tapply(Snail2$C18.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C18.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C18.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C18.0,Snail2$Treatment)

wilcox.test(Snail2$C18.0[Snail2$Treatment=="T"],Snail2$C18.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:0
tapply(Snail2$C20.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C20.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C20.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C20.0,Snail2$Treatment)

t.test(Snail2$C20.0[Snail2$Treatment=="T"],Snail2$C20.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C22:0
tapply(Snail2$C22.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C22.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C22.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C22.0,Snail2$Treatment)

t.test(Snail2$C22.0[Snail2$Treatment=="T"],Snail2$C22.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C23:0
tapply(Snail2$C23.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C23.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C23.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C23.0,Snail2$Treatment)

t.test(Snail2$C23.0[Snail2$Treatment=="T"],Snail2$C23.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C24:0
tapply(Snail2$C24.0,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C24.0[Snail2$Treatment=="C"])
qqPlot(Snail2$C24.0[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C24.0,Snail2$Treatment)

t.test(Snail2$C24.0[Snail2$Treatment=="T"],Snail2$C24.0[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C16:1n-7
tapply(Snail2$C16.1n.7,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C16.1n.7[Snail2$Treatment=="C"])
qqPlot(Snail2$C16.1n.7[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C16.1n.7,Snail2$Treatment)

wilcox.test(Snail2$C16.1n.7[Snail2$Treatment=="T"],Snail2$C16.1n.7[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C18:1n-7
tapply(Snail2$C18.1n.7,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C18.1n.7[Snail2$Treatment=="C"])
qqPlot(Snail2$C18.1n.7[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C18.1n.7,Snail2$Treatment)

wilcox.test(Snail2$C18.1n.7[Snail2$Treatment=="T"],Snail2$C18.1n.7[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C18:1n-9
tapply(Snail2$C18.1n.9c,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C18.1n.9c[Snail2$Treatment=="C"])
qqPlot(Snail2$C18.1n.9c[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C18.1n.9c,Snail2$Treatment)

wilcox.test(Snail2$C18.1n.9c[Snail2$Treatment=="T"],Snail2$C18.1n.9c[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# Tendenz

# C20:1n-9
tapply(Snail2$C20.1n.9,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C20.1n.9[Snail2$Treatment=="C"])
qqPlot(Snail2$C20.1n.9[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C20.1n.9,Snail2$Treatment)

wilcox.test(Snail2$C20.1n.9[Snail2$Treatment=="T"],Snail2$C20.1n.9[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C22:1n-9
tapply(Snail2$C22.1n.9,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C22.1n.9[Snail2$Treatment=="C"])
qqPlot(Snail2$C22.1n.9[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C22.1n.9,Snail2$Treatment)

t.test(Snail2$C22.1n.9[Snail2$Treatment=="T"],Snail2$C22.1n.9[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C18:2n-6c
tapply(Snail2$C18.2n.6c,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C18.2n.6c[Snail2$Treatment=="C"])
qqPlot(Snail2$C18.2n.6c[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C18.2n.6c,Snail2$Treatment)

wilcox.test(Snail2$C18.2n.6c[Snail2$Treatment=="T"],Snail2$C18.2n.6c[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C18:3n-3
tapply(Snail2$C18.3n.3,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C18.3n.3[Snail2$Treatment=="C"])
qqPlot(Snail2$C18.3n.3[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C18.3n.3,Snail2$Treatment)

wilcox.test(Snail2$C18.3n.3[Snail2$Treatment=="T"],Snail2$C18.3n.3[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C18:3n-6
tapply(Snail2$C18.3n.6,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C18.3n.6[Snail2$Treatment=="C"])
qqPlot(Snail2$C18.3n.6[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C18.3n.6,Snail2$Treatment)

t.test(Snail2$C18.3n.6[Snail2$Treatment=="T"],Snail2$C18.3n.6[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C20:2n-6
tapply(Snail2$C20.2n.6,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C20.2n.6[Snail2$Treatment=="C"])
qqPlot(Snail2$C20.2n.6[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C20.2n.6,Snail2$Treatment)

t.test(Snail2$C20.2n.6[Snail2$Treatment=="T"],Snail2$C20.2n.6[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C20:3n-3
tapply(Snail2$C20.3n.3,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C20.3n.3[Snail2$Treatment=="C"])
qqPlot(Snail2$C20.3n.3[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C20.3n.3,Snail2$Treatment)

wilcox.test(Snail2$C20.3n.3[Snail2$Treatment=="T"],Snail2$C20.3n.3[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:3n-6
tapply(Snail2$C20.3n.6,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C20.3n.6[Snail2$Treatment=="C"])
qqPlot(Snail2$C20.3n.6[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C20.3n.6,Snail2$Treatment)

t.test(Snail2$C20.3n.6[Snail2$Treatment=="T"],Snail2$C20.3n.6[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C20:4n-6
tapply(Snail2$C20.4n.6,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C20.4n.6[Snail2$Treatment=="C"])
qqPlot(Snail2$C20.4n.6[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C20.4n.6,Snail2$Treatment)

t.test(Snail2$C20.4n.6[Snail2$Treatment=="T"],Snail2$C20.4n.6[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C20:5n-3
tapply(Snail2$C20.5n.3,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C20.5n.3[Snail2$Treatment=="C"])
qqPlot(Snail2$C20.5n.3[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C20.5n.3,Snail2$Treatment)

t.test(Snail2$C20.5n.3[Snail2$Treatment=="T"],Snail2$C20.5n.3[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C22:6n-3
tapply(Snail2$C22.6n.3,Snail2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2$C22.6n.3[Snail2$Treatment=="C"])
qqPlot(Snail2$C22.6n.3[Snail2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2$C22.6n.3,Snail2$Treatment)

t.test(Snail2$C22.6n.3[Snail2$Treatment=="T"],Snail2$C22.6n.3[Snail2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# Snail2_sum
Snail2_sum<-rowSums(Snail2_ohneTR)
Snail2_sum<-cbind(Snail2[,c(1,2)],Snail2_sum)
boxplot(Snail2_sum~Treatment,Snail2_sum)

tapply(Snail2_sum$Snail2_sum,Snail2_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2_sum$Snail2_sum[Snail2_sum$Treatment=="C"])
qqPlot(Snail2_sum$Snail2_sum[Snail2_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2_sum$Snail2_sum,Snail2_sum$Treatment)

wilcox.test(Snail2_sum$Snail2_sum[Snail2_sum$Treatment=="T"],Snail2_sum$Snail2_sum[Snail2_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.
medians_sum2<-tapply(Snail2_sum$Snail2_sum,Snail2_sum$Treatment,median)
lower_sum2<-tapply(Snail2_sum$Snail2_sum,Snail2_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_sum2<-tapply(Snail2_sum$Snail2_sum,Snail2_sum$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_sum2,ui=upper_sum2,li=lower_sum2,ylim=c(0,25),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,5,10,15,20,25),labels=c(0,5,10,15,20,25),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Fatty acid content in �g/mg snail",at=12.5,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

# Snail2_SAFA
Snail2_SAFA<-rowSums(Snail2_ohneTR[,c("C12.0","C14.0","C15.0","C16.0","C17.0","C18.0","C20.0","C22.0","C23.0","C24.0")])
Snail2_SAFA<-cbind(Snail2[,c(1,2)],Snail2_SAFA)
tapply(Snail2_SAFA$Snail2_SAFA,Snail2_SAFA$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2_SAFA$Snail2_SAFA[Snail2_SAFA$Treatment=="C"])
qqPlot(Snail2_SAFA$Snail2_SAFA[Snail2_SAFA$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2_SAFA$Snail2_SAFA,Snail2_SAFA$Treatment)

wilcox.test(Snail2_SAFA$Snail2_SAFA[Snail2_SAFA$Treatment=="T"],Snail2_SAFA$Snail2_SAFA[Snail2_SAFA$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.
medians_SAFA2<-tapply(Snail2_SAFA$Snail2_SAFA,Snail2_SAFA$Treatment,median)
lower_SAFA2<-tapply(Snail2_SAFA$Snail2_SAFA,Snail2_SAFA$Treatment,function(x) ci.median(x)$ci[2])
upper_SAFA2<-tapply(Snail2_SAFA$Snail2_SAFA,Snail2_SAFA$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_SAFA2,ui=upper_SAFA2,li=lower_SAFA2,ylim=c(0,8),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,2,4,6,8),labels=c(0,2,4,6,8),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("SAFA content in �g/mg snail",at=4,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

# Snail2_MUFA
Snail2_MUFA<-rowSums(Snail2_ohneTR[,c("C16.1n.7","C18.1n.7","C18.1n.9c","C20.1n.9","C22.1n.9")])
Snail2_MUFA<-cbind(Snail2[,c(1,2)],Snail2_MUFA)
tapply(Snail2_MUFA$Snail2_MUFA,Snail2_MUFA$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2_MUFA$Snail2_MUFA[Snail2_MUFA$Treatment=="C"])
qqPlot(Snail2_MUFA$Snail2_MUFA[Snail2_MUFA$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2_MUFA$Snail2_MUFA,Snail2_MUFA$Treatment)

t.test(Snail2_MUFA$Snail2_MUFA[Snail2_MUFA$Treatment=="T"],Snail2_MUFA$Snail2_MUFA[Snail2_MUFA$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

medians_MUFA2<-tapply(Snail2_MUFA$Snail2_MUFA,Snail2_MUFA$Treatment,median)
lower_MUFA2<-tapply(Snail2_MUFA$Snail2_MUFA,Snail2_MUFA$Treatment,function(x) ci.median(x)$ci[2])
upper_MUFA2<-tapply(Snail2_MUFA$Snail2_MUFA,Snail2_MUFA$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_MUFA2,ui=upper_MUFA2,li=lower_MUFA2,ylim=c(0,6),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,1,2,3,4,5,6),labels=c(0,1,2,3,4,5,6),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("MUFA content in �g/mg leaf",at=3,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

# Snail2_PUFA
Snail2_PUFA<-rowSums(Snail2_ohneTR[,c("C18.2n.6c","C18.3n.3","C18.3n.6","C20.2n.6","C20.3n.3","C20.3n.6","C20.4n.6","C20.5n.3","C22.6n.3")])
Snail2_PUFA<-cbind(Snail2[,c(1,2)],Snail2_PUFA)
tapply(Snail2_PUFA$Snail2_PUFA,Snail2_PUFA$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Snail2_PUFA$Snail2_PUFA[Snail2_PUFA$Treatment=="C"])
qqPlot(Snail2_PUFA$Snail2_PUFA[Snail2_PUFA$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Snail2_PUFA$Snail2_PUFA,Snail2_PUFA$Treatment)

wilcox.test(Snail2_PUFA$Snail2_PUFA[Snail2_PUFA$Treatment=="T"],Snail2_PUFA$Snail2_PUFA[Snail2_PUFA$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.
medians_PUFA2<-tapply(Snail2_PUFA$Snail2_PUFA,Snail2_PUFA$Treatment,median)
lower_PUFA2<-tapply(Snail2_PUFA$Snail2_PUFA,Snail2_PUFA$Treatment,function(x) ci.median(x)$ci[2])
upper_PUFA2<-tapply(Snail2_PUFA$Snail2_PUFA,Snail2_PUFA$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_PUFA2,ui=upper_PUFA2,li=lower_PUFA2,ylim=c(0,12),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,2,4,6,8,10,12),labels=c(0,2,4,6,8,10,12),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("PUFA content in �g/mg leaf",at=6,side=2,line=4,cex=1.5)
lines(c(-0.15,3),c(0,0),type="l",lty=1,lwd=1.5)


#==============================================================
#### Multivariate statistics with & without sqrt transformation
#==============================================================


#### Absolute

Snail2_mult<-sqrt(Snail2_ohneTR)
#Snail2_mult<-log10(total_FAs_rel_ohneTR+1)
#Snail2_mult<-total_FAs_rel_ohneTR


# Assumption der PERMANOVA (=> gleiche Streuung innerhalb der Gruppen)
bd <- betadisper(vegdist(Snail2_mult), Treatments)
permutest(bd)


ad <- adonis2(Snail2_mult ~ Treatments)
ad # sig


# SIMPER (similarity percentage analysis)
simper <- simper(Snail2_mult, Treatments)
summary(simper)


# NMDS

#function to check for number of axis in NMDS
#NMDS is repeated 10 times for each dimension
#check for the influence of the random initial configurations
# x must be a data-object which can be coerced into a matrix
# max is the maximum number of dimensions
# dist_meas is the distance measure
scree_values<-function(x,max,dist_meas)
{
  xx<-as.matrix(x)
  scree.points = NULL
  scree.temp = 1
  for(i in 1:max)
  {
    sol.mds = NULL
    sol.mds <- replicate(10, metaMDS(xx, k=i, autotransform = FALSE, trymax=30, distance=dist_meas)$stress,
                         simplify=TRUE)
    scree.points<-append(scree.points,sol.mds)
  }
  return(scree.points)
}

# calculate relationship between dimensions and stress
scree.res<-scree_values(Snail2_mult, max=10, dist_meas ="bray") # "euclidean" oder "bray"

# plot dimensions vs stress
par(cex=1.5,las=1,xpd=FALSE)
plot_vec <- as.vector(sapply(1:(length(scree.res)/10), function(x) rep(x,10), simplify = "vector" ))

plot(plot_vec,scree.res,ylab = "Stress1",xlab = "dimensions")
lines(1:(length(scree.res)/10),as.vector((by(scree.res,plot_vec,mean))))
abline(h=.10,col="red")

#Selection of dimensions and Stress level (based and data transformation and resemblance metric)
FA_NMDS<-metaMDS(Snail2_mult,k=2, autotransform = FALSE ,distance = "bray")
FA_NMDS$stress

#Fits environmental factors and vectors
colnames(Snail2_mult)<-c("12:0","14:0","15:0","16:0","16:1n-7","17:0","18:0","18:1n-7","18:1n-9", "18:2n-6", "18:3n-3",  "18:3n-6",
                      "20:0","20:1n-9" ,"20:2n-6","20:3n-3","20:3n-6","20:4n-6","20:5n-3","22:0","22:1n-9","22:6n-3","23:0","24:0")


FA_variables.SAFAs<-envfit(FA_NMDS, subset(Snail2_mult,select = c("12:0","14:0","15:0","16:0","17:0","18:0","20:0","22:0","23:0","24:0"))
                           ,permutations = 999, na.rm = TRUE)
FA_variables.SAFAs

FA_variables.MUFAs<-envfit(FA_NMDS, subset(Snail2_mult,select = c("16:1n-7","18:1n-7","18:1n-9","20:1n-9","22:1n-9"))
                           ,permutations = 999, na.rm = TRUE)
FA_variables.MUFAs

FA_variables.PUFAs<-envfit(FA_NMDS, subset(Snail2_mult,select = c("18:2n-6","18:3n-3","18:3n-6","20:2n-6","20:3n-3","20:3n-6","20:4n-6","20:5n-3","22:6n-3"))
                           ,permutations = 999, na.rm = TRUE)
FA_variables.PUFAs

#plot Shepard diagram (Linear R^2 explain variation of regression of observed distances against ordination distances)
stressplot(FA_NMDS)

# NMDS Plot

par(mar=c(4.6,4.6,2.1,2.1),xpd=TRUE)
plotdf <- data.frame(FA_NMDS$points, Treatments)

points <- c(rep(21,6),rep(22,6))
color<-c(rep("black",6),rep("black",6))
fill_color<-c(rep("white",6),rep("grey50",6))

plot(c(0,1),c(0,1),type="n",xaxs="i",yaxs="i",xlim=c(-.4,.4),ylim=c(-.3,.3),axes=FALSE,bty="l",xlab="",ylab="",
     las=1,cex.lab=1.2,cex=1.2,cex.axis=1.2,lwd=1.5)
points( plotdf$MDS1, plotdf$MDS2, col=color,bg=fill_color, cex = 1.2, pch=points)
#ordispider(FA_NMDS, plotdf$Treatments,label=FALSE,cex = 1)
#points(rev(tapply(plotdf$MDS1,plotdf$Treatments,mean)),rev(tapply(plotdf$MDS2,plotdf$Treatments,mean)),bg=rev(c("white","black")),pch=22,cex=2)
axis(side=2, at=c(-.30,-.20,-.10,.0,.10,.20,.30), labels=c("-0.30","-0.20","-0.10", "0.00", "0.10", "0.20","0.30"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
axis(side=1, at=c(-.40,-.30,-.20,-.10,.0,.10,.20,.30,.40), labels=c("-0.40","-0.30","-0.20","-0.10", "0.00", "0.10", "0.20","0.30","0.40"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
text(-.48,.0,"NMDS2", cex=1.2, xpd=NA,srt=90)
text(.0,-.36,"NMDS1", cex=1.2, xpd=NA,srt=0)
legend("bottomright","stress: 0.009",bty="n",cex=1.2)
ordiellipse(FA_NMDS, Treatments,kind="sd",conf=0.95, col=c("grey80","black"), lwd=2,lty=c(1,6))
# Farben der Treatments: Control = 1. solid, Treatment = 6. twodash
plot(FA_variables.SAFAs,col="darkorchid3")
plot(FA_variables.MUFAs,col="blue")
plot(FA_variables.PUFAs,col="chartreuse4")




# Grafik f�r Verteidigung

par(mar=c(4.6,4.6,2.1,2.1),xpd=TRUE)
plotdf <- data.frame(FA_NMDS$points, Treatments)

points <- c(rep(22,6),rep(22,6))
color<-c(rep("black",6),rep("black",6))
fill_color<-c(rep("cornflowerblue",6),rep("orange",6))

plot(c(0,1),c(0,1),type="n",xaxs="i",yaxs="i",xlim=c(-.4,.4),ylim=c(-.3,.3),axes=FALSE,bty="l",xlab="",ylab="",
     las=1,cex.lab=1.2,cex=1.2,cex.axis=1.2,lwd=1.5)
points( plotdf$MDS1, plotdf$MDS2, col=color,bg=fill_color, cex = 1.2, pch=points)
ordispider(FA_NMDS, plotdf$Treatments,label=FALSE,cex = 1)
points(rev(tapply(plotdf$MDS1,plotdf$Treatments,mean)),rev(tapply(plotdf$MDS2,plotdf$Treatments,mean)),bg=rev(c("cornflowerblue","orange")),pch=22,cex=2)
axis(side=2, at=c(-.30,-.15,.0,.15,.30), labels=c("-0.30","-0.15", "0.00", "0.15","0.30"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
axis(side=1, at=c(-.40,-.20,.0,.20,.40), labels=c("-0.40","-0.20", "0.00","0.20","0.40"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
text(-.6,.0,"NMDS2", cex=1.2, xpd=NA,srt=90)
text(.0,-.43,"NMDS1", cex=1.2, xpd=NA,srt=0)

# 6 x 7



data.scores = as.data.frame(scores(FA_NMDS))
data.scores$Treatment = Treatments

SAFAs_coord_cont = as.data.frame(scores(FA_variables.SAFAs, "vectors")) * ordiArrowMul(FA_variables.SAFAs)
MUFAs_coord_cont = as.data.frame(scores(FA_variables.MUFAs, "vectors")) * ordiArrowMul(FA_variables.MUFAs)
PUFAs_coord_cont = as.data.frame(scores(FA_variables.PUFAs, "vectors")) * ordiArrowMul(FA_variables.PUFAs)

library(ggplot2)
library(ggrepel)
ggplot(data = data.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_point(data = data.scores, size = 7,shape=c(rep(21,6),rep(22,6)),
             fill=c(rep("white",6),rep("grey50",6)), color="black",stroke = 1.5) +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = SAFAs_coord_cont, size =2, alpha = 0.5, colour = "darkorange") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = MUFAs_coord_cont, size =2, alpha = 0.5, colour = "deepskyblue3") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = PUFAs_coord_cont, size =2, alpha = 0.5, colour = "chartreuse3") +
  geom_text_repel(data = SAFAs_coord_cont, aes(x = NMDS1, y = NMDS2),
                  box.padding = 1.5, direction= "both", segment.size = 2, segment.color = "darkorange",
                  nudge_x = c(-.01,-.01,-.01,-.01,-.01,-.01,-.01,-.01,-.01,-.01),
                  alpha = 0.5, size =7.5, colour = "black", fontface = "bold", label = row.names(SAFAs_coord_cont)) +
  geom_text(data = MUFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(MUFAs_coord_cont)) +
  geom_text(data = PUFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(PUFAs_coord_cont)) +
  theme(axis.title = element_text(size = 20, colour = "black"),
        panel.background = element_blank(), panel.border = element_rect(fill = NA, colour = "black"),
        axis.ticks = element_blank(), axis.text = element_blank())


#### Relative
relSnail_mult<-total_FAs_rel_ohneTR/100
relSnail_mult<-sqrt(relSnail_mult)
#Snail2_mult<-log10(total_FAs_rel_ohneTR+1)
#Snail2_mult<-total_FAs_rel_ohneTR


# Assumption der PERMANOVA (=> gleiche Streuung innerhalb der Gruppen)
bd <- betadisper(vegdist(relSnail_mult), Treatments)
permutest(bd)


ad <- adonis2(relSnail_mult ~ Treatments)
ad # sig


# SIMPER (similarity percentage analysis)
simper <- simper(relSnail_mult, Treatments)
summary(simper)


# NMDS

#function to check for number of axis in NMDS
#NMDS is repeated 10 times for each dimension
#check for the influence of the random initial configurations
# x must be a data-object which can be coerced into a matrix
# max is the maximum number of dimensions
# dist_meas is the distance measure
scree_values<-function(x,max,dist_meas)
{
  xx<-as.matrix(x)
  scree.points = NULL
  scree.temp = 1
  for(i in 1:max)
  {
    sol.mds = NULL
    sol.mds <- replicate(10, metaMDS(xx, k=i, autotransform = FALSE, trymax=30, distance=dist_meas)$stress,
                         simplify=TRUE)
    scree.points<-append(scree.points,sol.mds)
  }
  return(scree.points)
}

# calculate relationship between dimensions and stress
scree.res<-scree_values(relSnail_mult, max=10, dist_meas ="bray") # "euclidean" oder "bray"

# plot dimensions vs stress
par(cex=1.5,las=1,xpd=FALSE)
plot_vec <- as.vector(sapply(1:(length(scree.res)/10), function(x) rep(x,10), simplify = "vector" ))

plot(plot_vec,scree.res,ylab = "Stress1",xlab = "dimensions")
lines(1:(length(scree.res)/10),as.vector((by(scree.res,plot_vec,mean))))
abline(h=.10,col="red")

#Selection of dimensions and Stress level (based and data transformation and resemblance metric)
relFA_NMDS<-metaMDS(relSnail_mult,k=2, autotransform = FALSE ,distance = "bray")
relFA_NMDS$stress

#Fits environmental factors and vectors
colnames(relSnail_mult)<-c("12:0","14:0","15:0","16:0","16:1n-7","17:0","18:0","18:1n-7","18:1n-9", "18:2n-6", "18:3n-3",  "18:3n-6",
                         "20:0","20:1n-9" ,"20:2n-6","20:3n-3","20:3n-6","20:4n-6","20:5n-3","22:0","22:1n-9","22:6n-3","23:0","24:0")


relFA_variables.SAFAs<-envfit(relFA_NMDS, subset(relSnail_mult,select = c("12:0","14:0","15:0","16:0","17:0","18:0","20:0","22:0","23:0","24:0"))
                           ,permutations = 999, na.rm = TRUE)
relFA_variables.SAFAs

relFA_variables.MUFAs<-envfit(relFA_NMDS, subset(relSnail_mult,select = c("16:1n-7","18:1n-7","18:1n-9","20:1n-9","22:1n-9"))
                           ,permutations = 999, na.rm = TRUE)
relFA_variables.MUFAs

relFA_variables.PUFAs<-envfit(relFA_NMDS, subset(relSnail_mult,select = c("18:2n-6","18:3n-3","18:3n-6","20:2n-6","20:3n-3","20:3n-6","20:4n-6","20:5n-3","22:6n-3"))
                           ,permutations = 999, na.rm = TRUE)
relFA_variables.PUFAs

#plot Shepard diagram (Linear R^2 explain variation of regression of observed distances against ordination distances)
stressplot(relFA_NMDS)

# NMDS Plot

par(mar=c(4.6,4.6,2.1,2.1),xpd=TRUE)
plotdf <- data.frame(relFA_NMDS$points, Treatments)

points <- c(rep(21,6),rep(22,6))
color<-c(rep("black",6),rep("black",6))
fill_color<-c(rep("white",6),rep("grey50",6))

plot(c(0,1),c(0,1),type="n",xaxs="i",yaxs="i",xlim=c(-.4,.4),ylim=c(-.3,.3),axes=FALSE,bty="l",xlab="",ylab="",
     las=1,cex.lab=1.2,cex=1.2,cex.axis=1.2,lwd=1.5)
points( plotdf$MDS1, plotdf$MDS2, col=color,bg=fill_color, cex = 1.2, pch=points)
#ordispider(relFA_NMDS, plotdf$Treatments,label=FALSE,cex = 1)
#points(rev(tapply(plotdf$MDS1,plotdf$Treatments,mean)),rev(tapply(plotdf$MDS2,plotdf$Treatments,mean)),bg=rev(c("white","black")),pch=22,cex=2)
axis(side=2, at=c(-.30,-.20,-.10,.0,.10,.20,.30), labels=c("-0.30","-0.20","-0.10", "0.00", "0.10", "0.20","0.30"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
axis(side=1, at=c(-.40,-.30,-.20,-.10,.0,.10,.20,.30,.40), labels=c("-0.40","-0.30","-0.20","-0.10", "0.00", "0.10", "0.20","0.30","0.40"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
text(-.48,.0,"NMDS2", cex=1.2, xpd=NA,srt=90)
text(.0,-.36,"NMDS1", cex=1.2, xpd=NA,srt=0)
legend("bottomright","stress: 0.009",bty="n",cex=1.2)
ordiellipse(relFA_NMDS, Treatments,kind="sd",conf=0.95, col=c("grey80","black"), lwd=2,lty=c(1,6))
# Farben der Treatments: Control = 1. solid, Treatment = 6. twodash
plot(relFA_variables.SAFAs,col="darkorchid3")
plot(relFA_variables.MUFAs,col="blue")
plot(relFA_variables.PUFAs,col="chartreuse4")


data.scores = as.data.frame(scores(relFA_NMDS))
data.scores$Treatment = Treatments

relSAFAs_coord_cont = as.data.frame(scores(relFA_variables.SAFAs, "vectors")) * ordiArrowMul(relFA_variables.SAFAs)
relMUFAs_coord_cont = as.data.frame(scores(relFA_variables.MUFAs, "vectors")) * ordiArrowMul(relFA_variables.MUFAs)
relPUFAs_coord_cont = as.data.frame(scores(relFA_variables.PUFAs, "vectors")) * ordiArrowMul(relFA_variables.PUFAs)

ggplot(data = data.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_point(data = data.scores, size = 7,shape=c(rep(21,6),rep(22,6)),
             fill=c(rep("white",6),rep("grey50",6)), color="black",stroke = 1.5) +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = relSAFAs_coord_cont, size =2, alpha = 0.5, colour = "darkorange") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = relMUFAs_coord_cont, size =2, alpha = 0.5, colour = "deepskyblue3") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = relPUFAs_coord_cont, size =2, alpha = 0.5, colour = "chartreuse3") +
  geom_text(data = relSAFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(relSAFAs_coord_cont)) +
  geom_text(data = relMUFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(relMUFAs_coord_cont)) +
  geom_text(data = relPUFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(relPUFAs_coord_cont)) +
  theme(axis.title = element_text(size = 20, colour = "black"),
        panel.background = element_blank(), panel.border = element_rect(fill = NA, colour = "black"),
        axis.ticks = element_blank(), axis.text = element_blank())

