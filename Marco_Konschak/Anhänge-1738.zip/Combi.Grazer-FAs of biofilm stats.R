library(vegan)
library(multcomp)
library(car)
library(data.table)
library(asbio)
library(plotrix)
library(readxl)
library(lmtest)

Biofilm<-data.table(read.table("2019-10-27-Grazer-FAs of biofilm.txt"))
Biofilm[, Name := as.character(Name)]
Biofilm[, RUNINFO := as.character(RUNINFO)]
Biofilm[, Run := as.factor(Run)]
Biofilm[, Treatment := as.factor(Treatment)]
Biofilm[, Replicate := as.character(Replicate)]
Biofilm[, FA_mass := as.numeric(FA_mass)]
Biofilm[, �g_FA_per_mg := as.numeric(�g_FA_per_mg)]

Biofilm<-Biofilm[order(Treatment),]
Biofilm[,Name := gsub(" ", "", Name)]

Names<-unique(Biofilm$Name)
Names
RUNINFOs<-Biofilm$RUNINFO[Biofilm$Name=="16:0"]
Runs<-Biofilm$Run[Biofilm$Name=="16:0"]
Treatments<-Biofilm$Treatment[Biofilm$Name=="16:0"]
Replicates<-Biofilm$Replicate[Biofilm$Name=="16:0"]

`C15:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="15:0"]
`C16:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="16:0"]
`C16:1n-7` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="16:1n-7"]
`C17:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="17:0"]
`C18:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="18:0"]
`C20:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="20:0"]
`C18:1n-7` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="18:1n-7"]
`C18:1n-9c`<-Biofilm$�g_FA_per_mg[Biofilm$Name=="18:1n-9c"]
`C18:2n-6c`<-Biofilm$�g_FA_per_mg[Biofilm$Name=="18:2n-6c"]
`C18:3n-3` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="18:3n-3"]
`C18:3n-6` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="18:3n-6"]
`C20:1n-9` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="20:1n-9"]
`C20:2n-6` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="20:2n-6"]
`C20:3n-3` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="20:3n-3"]
`C20:4n-6` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="20:4n-6"]
`C20:5n-3` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="20:5n-3"]
`C22:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="22:0"]
`C22:6n-3` <-Biofilm$�g_FA_per_mg[Biofilm$Name=="22:6n-3"]
`C23:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="23:0"]
`C24:0`    <-Biofilm$�g_FA_per_mg[Biofilm$Name=="24:0"]

Biofilm2<-data.table(data.frame(RUNINFO=RUNINFOs,Run=Runs,Treatment=Treatments,Replicate=Replicates,
                             `C15:0`=`C15:0`,`C16:0`=`C16:0`,`C16:1n-7`=`C16:1n-7`,`C17:0`=`C17:0`,`C18:0`=`C18:0`,
                             `C18:1n-7`=`C18:1n-7`,`C18:1n-9c`=`C18:1n-9c`,`C18:2n-6c`=`C18:2n-6c`,`C18:3n-3`=`C18:3n-3`,
                             `C18:3n-6`=`C18:3n-6`,`C20:0`=`C20:0`,`C20:1n-9`=`C20:1n-9`,`C20:2n-6`=`C20:2n-6`,`C20:3n-3`=`C20:3n-3`,
                             `C20:4n-6`=`C20:4n-6`,`C20:5n-3`=`C20:5n-3`,`C22:0`=`C22:0`,`C22:6n-3`=`C22:6n-3`,`C23:0`=`C23:0`,`C24:0`=`C24:0`))


Biofilm2_ohneTR<-Biofilm2[,c(-1,-2,-3,-4)]


`X_C15:0`    <-Biofilm$FA_mass[Biofilm$Name=="15:0"]
`X_C16:0`    <-Biofilm$FA_mass[Biofilm$Name=="16:0"]
`X_C16:1n-7` <-Biofilm$FA_mass[Biofilm$Name=="16:1n-7"]
`X_C17:0`    <-Biofilm$FA_mass[Biofilm$Name=="17:0"]
`X_C18:0`    <-Biofilm$FA_mass[Biofilm$Name=="18:0"]
`X_C18:1n-7` <-Biofilm$FA_mass[Biofilm$Name=="18:1n-7"]
`X_C18:1n-9c`<-Biofilm$FA_mass[Biofilm$Name=="18:1n-9c"]
`X_C18:2n-6c`<-Biofilm$FA_mass[Biofilm$Name=="18:2n-6c"]
`X_C18:3n-3` <-Biofilm$FA_mass[Biofilm$Name=="18:3n-3"]
`X_C18:3n-6` <-Biofilm$FA_mass[Biofilm$Name=="18:3n-6"]
`X_C20:0`    <-Biofilm$FA_mass[Biofilm$Name=="20:0"]
`X_C20:1n-9` <-Biofilm$FA_mass[Biofilm$Name=="20:1n-9"]
`X_C20:2n-6` <-Biofilm$FA_mass[Biofilm$Name=="20:2n-6"]
`X_C20:3n-3` <-Biofilm$FA_mass[Biofilm$Name=="20:3n-3"]
`X_C20:4n-6` <-Biofilm$FA_mass[Biofilm$Name=="20:4n-6"]
`X_C20:5n-3` <-Biofilm$FA_mass[Biofilm$Name=="20:5n-3"]
`X_C22:0`    <-Biofilm$FA_mass[Biofilm$Name=="22:0"]
`X_C22:6n-3` <-Biofilm$FA_mass[Biofilm$Name=="22:6n-3"]
`X_C23:0`    <-Biofilm$FA_mass[Biofilm$Name=="23:0"]
`X_C24:0`    <-Biofilm$FA_mass[Biofilm$Name=="24:0"]


total_FAs<-data.table(data.frame(RUNINFO=RUNINFOs,Run=Runs,Treatment=Treatments,Replicate=Replicates,
                             `C15:0`=`X_C15:0`,`C16:0`=`X_C16:0`,`C16:1n-7`=`X_C16:1n-7`,`C17:0`=`X_C17:0`,`C18:0`=`X_C18:0`,`C18:1n-7`=`X_C18:1n-7`,
                             `C18:1n-9c`=`X_C18:1n-9c`,`C18:2n-6c`=`X_C18:2n-6c`, `C18:3n-3`=`X_C18:3n-3`,`C18:3n-6`=`X_C18:3n-6`,`C20:0`=`X_C20:0`,
                             `C20:1n-9`=`X_C20:1n-9`,`C20:2n-6`=`X_C20:2n-6`,`C20:3n-3`=`X_C20:3n-3`,
                             `C20:4n-6`=`X_C20:4n-6`,`C20:5n-3`=`X_C20:5n-3`,`C22:0`=`X_C22:0`,
                             `C22:6n-3`=`X_C22:6n-3`,`C23:0`=`X_C23:0`,`C24:0`=`X_C24:0`))


###relativ
total_FAs_ohneTR<-total_FAs[,c(-1,-2,-3,-4)]
total_FAs_rel_ohneTR<-total_FAs_ohneTR/rowSums(total_FAs_ohneTR)*100
rowSums(total_FAs_rel_ohneTR)
total_FAs_rel<-cbind(total_FAs[,c(1,2,3,4)],total_FAs_rel_ohneTR)

Parameters<-data.table(read_excel("2019-03-07-Grazer-Environm. parameters.xlsx"))
Parameters[, Run := as.factor(Run)]
Parameters[, Treatment := as.factor(Treatment)]
Parameters[, Replicate := as.character(Replicate)]
Parameters[, ID := as.factor(ID)]
Parameters[, Concentration := as.numeric(Concentration)]
Parameters[, pH := as.numeric(pH)]
Parameters[, O2 := as.numeric(O2)]
Parameters[, Conductivity := as.numeric(Conductivity)]
Parameters[, Velocity := as.numeric(Velocity)]
Parameters[, Illuminance := as.numeric(Illuminance)]
Parameters[, PhotoActRad := as.numeric(PhotoActRad)]

# SAFA

m_C15.0<-tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,median)
m_C15.0<-m_C15.0[!is.na(m_C15.0)]
lower_C15.0<-tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C15.0<-lower_C15.0[!is.na(lower_C15.0)]
upper_C15.0<-tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C15.0<-upper_C15.0[!is.na(upper_C15.0)]

m_C16.0<-tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,median)
m_C16.0 <- m_C16.0[!is.na(m_C16.0)]
lower_C16.0<-tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C16.0<-lower_C16.0[!is.na(lower_C16.0)]
upper_C16.0<-tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C16.0<-upper_C16.0[!is.na(upper_C16.0)]

m_C17.0<-tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,median)
m_C17.0 <- m_C17.0[!is.na(m_C17.0)]
lower_C17.0<-tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C17.0<-lower_C17.0[!is.na(lower_C17.0)]
upper_C17.0<-tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C17.0<-upper_C17.0[!is.na(upper_C17.0)]

m_C18.0<-tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,median)
m_C18.0<-m_C18.0[!is.na(m_C18.0)]
lower_C18.0<-tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.0<-lower_C18.0[!is.na(lower_C18.0)]
upper_C18.0<-tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.0<-upper_C18.0[!is.na(upper_C18.0)]

m_C20.0<-tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,median)
m_C20.0<-m_C20.0[!is.na(m_C20.0)]
lower_C20.0<-tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.0<-lower_C20.0[!is.na(lower_C20.0)]
upper_C20.0<-tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.0<-upper_C20.0[!is.na(upper_C20.0)]

m_C22.0<-tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,median)
m_C22.0<-m_C22.0[!is.na(m_C22.0)]
lower_C22.0<-tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C22.0<-lower_C22.0[!is.na(lower_C22.0)]
upper_C22.0<-tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C22.0<-upper_C22.0[!is.na(upper_C22.0)]

m_C23.0<-tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,median)
m_C23.0<-m_C23.0[!is.na(m_C23.0)]
lower_C23.0<-tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C23.0<-lower_C23.0[!is.na(lower_C23.0)]
upper_C23.0<-tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C23.0<-upper_C23.0[!is.na(upper_C23.0)]

m_C24.0<-tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,median)
m_C24.0<-m_C24.0[!is.na(m_C24.0)]
lower_C24.0<-tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C24.0<-lower_C24.0[!is.na(lower_C24.0)]
upper_C24.0<-tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C24.0<-upper_C24.0[!is.na(upper_C24.0)]

# MUFA

m_C16.1n.7<-tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,median)
m_C16.1n.7 <- m_C16.1n.7[!is.na(m_C16.1n.7)]
lower_C16.1n.7<-tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C16.1n.7<-lower_C16.1n.7[!is.na(lower_C16.1n.7)]
upper_C16.1n.7<-tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C16.1n.7<-upper_C16.1n.7[!is.na(upper_C16.1n.7)]

m_C18.1n.7<-tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,median)
m_C18.1n.7 <- m_C18.1n.7[!is.na(m_C18.1n.7)]
lower_C18.1n.7<-tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.1n.7<-lower_C18.1n.7[!is.na(lower_C18.1n.7)]
upper_C18.1n.7<-tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.1n.7<-upper_C18.1n.7[!is.na(upper_C18.1n.7)]

m_C18.1n.9c<-tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,median)
m_C18.1n.9c<-m_C18.1n.9c[!is.na(m_C18.1n.9c)]
lower_C18.1n.9c<-tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.1n.9c<-lower_C18.1n.9c[!is.na(lower_C18.1n.9c)]
upper_C18.1n.9c<-tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.1n.9c<-upper_C18.1n.9c[!is.na(upper_C18.1n.9c)]

m_C20.1n.9<-tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,median)
m_C20.1n.9<-m_C20.1n.9[!is.na(m_C20.1n.9)]
lower_C20.1n.9<-tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.1n.9<-lower_C20.1n.9[!is.na(lower_C20.1n.9)]
upper_C20.1n.9<-tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.1n.9<-upper_C20.1n.9[!is.na(upper_C20.1n.9)]

# PUFA

m_C18.2n.6c<-tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,median)
m_C18.2n.6c<-m_C18.2n.6c[!is.na(m_C18.2n.6c)]
lower_C18.2n.6c<-tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.2n.6c<-lower_C18.2n.6c[!is.na(lower_C18.2n.6c)]
upper_C18.2n.6c<-tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.2n.6c<-upper_C18.2n.6c[!is.na(upper_C18.2n.6c)]

m_C18.3n.3<-tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,median)
m_C18.3n.3<-m_C18.3n.3[!is.na(m_C18.3n.3)]
lower_C18.3n.3<-tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.3n.3<-lower_C18.3n.3[!is.na(lower_C18.3n.3)]
upper_C18.3n.3<-tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.3n.3<-upper_C18.3n.3[!is.na(upper_C18.3n.3)]

m_C18.3n.6<-tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,median)
m_C18.3n.6<-m_C18.3n.6[!is.na(m_C18.3n.6)]
lower_C18.3n.6<-tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C18.3n.6<-lower_C18.3n.6[!is.na(lower_C18.3n.6)]
upper_C18.3n.6<-tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C18.3n.6<-upper_C18.3n.6[!is.na(upper_C18.3n.6)]

m_C20.2n.6<-tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,median)
m_C20.2n.6<-m_C20.2n.6[!is.na(m_C20.2n.6)]
lower_C20.2n.6<-tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.2n.6<-lower_C20.2n.6[!is.na(lower_C20.2n.6)]
upper_C20.2n.6<-tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.2n.6<-upper_C20.2n.6[!is.na(upper_C20.2n.6)]

m_C20.3n.3<-tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,median)
m_C20.3n.3<-m_C20.3n.3[!is.na(m_C20.3n.3)]
lower_C20.3n.3<-tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.3n.3<-lower_C20.3n.3[!is.na(lower_C20.3n.3)]
upper_C20.3n.3<-tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.3n.3<-upper_C20.3n.3[!is.na(upper_C20.3n.3)]

m_C20.4n.6<-tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,median)
m_C20.4n.6<-m_C20.4n.6[!is.na(m_C20.4n.6)]
lower_C20.4n.6<-tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.4n.6<-lower_C20.4n.6[!is.na(lower_C20.4n.6)]
upper_C20.4n.6<-tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.4n.6<-upper_C20.4n.6[!is.na(upper_C20.4n.6)]

m_C20.5n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,median)
m_C20.5n.3<-m_C20.5n.3[!is.na(m_C20.5n.3)]
lower_C20.5n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C20.5n.3<-lower_C20.5n.3[!is.na(lower_C20.5n.3)]
upper_C20.5n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C20.5n.3<-upper_C20.5n.3[!is.na(upper_C20.5n.3)]

m_C22.6n.3<-tapply(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment,median)
m_C22.6n.3<-m_C22.6n.3[!is.na(m_C22.6n.3)]
lower_C22.6n.3<-tapply(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[2])
lower_C22.6n.3<-lower_C22.6n.3[!is.na(lower_C22.6n.3)]
upper_C22.6n.3<-tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,function(x) ci.median(x)$ci[3])
upper_C22.6n.3<-upper_C22.6n.3[!is.na(upper_C22.6n.3)]

m_sat<-c(m_C15.0,m_C16.0,m_C17.0,m_C18.0,m_C20.0,m_C22.0,m_C23.0,m_C24.0)
m_mono<-c(m_C16.1n.7,m_C18.1n.7,m_C18.1n.9c,m_C20.1n.9)
m_poly<-c(m_C18.2n.6c,m_C18.3n.3,m_C18.3n.6,m_C20.2n.6,m_C20.3n.3,m_C20.4n.6,m_C20.5n.3,m_C22.6n.3)

lower_sat<-c(lower_C15.0,lower_C16.0,lower_C17.0,lower_C18.0,lower_C20.0,lower_C22.0,lower_C23.0,lower_C24.0)
lower_mono<-c(lower_C16.1n.7,lower_C18.1n.7,lower_C18.1n.9c,lower_C20.1n.9)
lower_poly<-c(lower_C18.2n.6c,lower_C18.3n.3,lower_C18.3n.6,lower_C20.2n.6,lower_C20.3n.3,lower_C20.4n.6,lower_C20.5n.3,lower_C22.6n.3)

upper_sat<-c(upper_C15.0,upper_C16.0,upper_C17.0,upper_C18.0,upper_C20.0,upper_C22.0,upper_C23.0,upper_C24.0)
upper_mono<-c(upper_C16.1n.7,upper_C18.1n.7,upper_C18.1n.9c,upper_C20.1n.9)
upper_poly<-c(upper_C18.2n.6c,upper_C18.3n.3,lower_C18.3n.6,upper_C20.2n.6,upper_C20.3n.3,upper_C20.4n.6,upper_C20.5n.3,upper_C22.6n.3)

m_all<-c(m_sat,m_mono,m_poly)
lower_all<-c(lower_sat,lower_mono,lower_poly)
upper_all<-c(upper_sat,upper_mono,upper_poly)

SAFA_cumulative<-data.table(data.frame(FA=c(rep("15:0",times=2),rep("16:0",times=2),rep("17:0",times=2),rep("18:0",times=2),rep("20:0",times=2),
                                            rep("22:0",times=2),rep("23:0",times=2),rep("24:0",times=2)),
                                       Treatment=rep(c("C","T"),times=8),mSAFA=m_sat,lSAFA=lower_sat,uSAFA=upper_sat))
tapply(SAFA_cumulative$mSAFA,SAFA_cumulative$Treatment,sum)
tapply(SAFA_cumulative$lSAFA,SAFA_cumulative$Treatment,sum)
tapply(SAFA_cumulative$uSAFA,SAFA_cumulative$Treatment,sum)


MUFA_cumulative<-data.table(data.frame(FA=c(rep("16:1n-7",times=2),rep("18:1n-7",times=2),rep("18:1n-9",times=2),rep("20:1n-9",times=2)),
                                       Treatment=rep(c("C","T"),times=4),mMUFA=m_mono,lMUFA=lower_mono,uMUFA=upper_mono))
tapply(MUFA_cumulative$mMUFA,MUFA_cumulative$Treatment,sum)
tapply(MUFA_cumulative$lMUFA,MUFA_cumulative$Treatment,sum)
tapply(MUFA_cumulative$uMUFA,MUFA_cumulative$Treatment,sum)



PUFA_cumulative<-data.table(data.frame(FA=c(rep("18:2n-6",times=2),rep("18:3n-3",times=2),rep("18:3n-6",times=2),rep("20:2n-6",times=2),rep("20:3n-3",times=2),rep("20:4n-6",times=2),rep("20:5n-3",times=2),rep("22:6n-3",times=2)),
                                       Treatment=rep(c("C","T"),times=8),mPUFA=m_poly,lPUFA=lower_poly,uPUFA=upper_poly))
tapply(PUFA_cumulative$mPUFA,PUFA_cumulative$Treatment,sum)
tapply(PUFA_cumulative$lPUFA,PUFA_cumulative$Treatment,sum)
tapply(PUFA_cumulative$uPUFA,PUFA_cumulative$Treatment,sum)


require(gplots)
par(mar=c(5, 4.5, 4, 2) + 0.1,xpd=FALSE)
barplot2(m_sat,space=c(1,0,1,0),xpd=FALSE,plot.ci=TRUE,ci.u=upper_sat,ci.l=lower_sat,ylim=c(0,30),
         las=1,yaxs="i",bty ="n",xaxt = "n",ylab=expression("Proportion of sat. FAs in %"),
         xlab=expression("Fatty acid"),col=c("white","red"),cex.axis=1.5,cex.lab=1.5,lwd=1.5,ci.lwd=1.5)
axis(1,at=c(2,5,8,11,14,17,20,23),labels=c("15:0","16:0","17:0","18:0","20:0","22:0","23:0","24:0"),tick=TRUE,cex.axis=1.5)
lines(c(-0.5,31),c(0,0),type="l",lty=1,lwd=1.5)

barplot2(m_mono,space=c(1,0,1,0),xpd=FALSE,plot.ci=TRUE,ci.u=upper_mono,ci.l=lower_mono,ylim=c(0,14),
         las=1,yaxs="i",bty ="n",xaxt = "n",ylab=expression("Proportion of monounsat. FAs in %"),
         xlab=expression("Fatty acid"),col=c("white","red"),cex.axis=1.5,cex.lab=1.5,lwd=1.5,ci.lwd=1.5)
axis(1,at=c(2,5,8,11),labels=c("16:1n-7","18:1n-7","18:1n-9","20:1n-9"),tick=TRUE,cex.axis=1.5)
lines(c(0,21),c(0,0),type="l",lty=1,lwd=1.5)

barplot2(m_poly,space=c(1,0,1,0),xpd=FALSE,plot.ci=TRUE,ci.u=upper_poly,ci.l=lower_poly,ylim=c(0,50),
         las=1,yaxs="i",bty ="n",xaxt = "n",ylab=expression("Proportion of polyunsat. FAs in %"),
         xlab=expression("Fatty acid"),col=c("white","red"),cex.axis=1.5,cex.lab=1.5,lwd=1.5,ci.lwd=1.5)
axis(1,at=c(2,5,8,11,14,17,20,23),labels=c("18:2n-6","18:3n-3","18:3n-6","20:2n-6","20:3n-3","20:4n-6","20:5n-3","22:6n-3"),tick=TRUE,cex.axis=1.5)
lines(c(-0.5,31),c(0,0),type="l",lty=1,lwd=1.5)

detach(package:gplots,unload=TRUE)


#### Table: relative FAs

MediansCIs<- data.frame(matrix(nrow = ncol(total_FAs_rel_ohneTR)*ncol(total_FAs_rel_ohneTR)+ncol(total_FAs_rel_ohneTR)+1, ncol = 6))
colnames(MediansCIs) <- c("Name","Treatment","Median", "lower CI","to","upper CI")
for(i in 1:ncol(total_FAs_rel_ohneTR))
{
  Medians  <-tapply(total_FAs_rel_ohneTR[[i]],total_FAs_rel$Treatment,median)
  CIs_lower<-tapply(total_FAs_rel_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[1])
  CIs_upper<-tapply(total_FAs_rel_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[2])

  MediansCIs[i*i+i, 1] <- Names[i]
  MediansCIs[i*i+i, 2] <- "Control"
  MediansCIs[i*i+i, 3] <- unname(Medians[!is.na(Medians)])[1]
  MediansCIs[i*i+i, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[1]
  MediansCIs[i*i+i, 5] <- "to"
  MediansCIs[i*i+i, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[1]

  MediansCIs[i*i+i+1, 1] <- Names[i]
  MediansCIs[i*i+i+1, 2] <- "Treatment"
  MediansCIs[i*i+i+1, 3] <- unname(Medians[!is.na(Medians)])[2]
  MediansCIs[i*i+i+1, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[2]
  MediansCIs[i*i+i+1, 5] <- "to"
  MediansCIs[i*i+i+1, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[2]

}

MediansCIs<-subset(MediansCIs,! Name %in% NA)
MediansCIs[,c(3,4,6)]<-round(MediansCIs[,c(3,4,6)],2)
MediansCIs$M_CIs<-with(MediansCIs, paste0(`Median`," ","(",`lower CI`," " ,`to`," " ,`upper CI`,")" ))
MediansCIs<-MediansCIs[,-c(3,4,5,6)]
MediansCIs_C<-subset(MediansCIs,! Treatment %in% "Treatment")
MediansCIs_T<-subset(MediansCIs,Treatment %in% "Treatment")
MediansCIs<-cbind(MediansCIs_C,MediansCIs_T)
MediansCIs<-MediansCIs[,-c(2,4,5)]
colnames(MediansCIs)[2] <- "Control"
colnames(MediansCIs)[3] <- "Diuron"
#write.table(MediansCIs, file = "Grazer study-relative FAs of biofilm.txt", sep="\t")


#### Univariat RELATIV

# C15:0
tapply(total_FAs_rel$C15.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C15.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C15.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C15.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C15.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C15.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C16:0
tapply(total_FAs_rel$C16.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C16.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C16.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C16.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C16.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C16.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C17:0
tapply(total_FAs_rel$C17.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C17.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C17.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C17.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C17.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C17.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)


# C18:0
tapply(total_FAs_rel$C18.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C18.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C20:0
tapply(total_FAs_rel$C20.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C20.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C22:0
tapply(total_FAs_rel$C22.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C22.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C22.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C22.0,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C22.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C22.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C23:0
tapply(total_FAs_rel$C23.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C23.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C23.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C23.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C23.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C23.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C24:0
tapply(total_FAs_rel$C24.0,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C24.0[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C24.0[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C24.0,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C24.0[total_FAs_rel$Treatment=="T"],total_FAs_rel$C24.0[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C16:1n-7
tapply(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C16.1n.7,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="T"],total_FAs_rel$C16.1n.7[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:1n-7
tapply(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.1n.7,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.1n.7[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:1n-9
tapply(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.1n.9c,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.1n.9c[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C20:1n-9
tapply(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.1n.9,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.1n.9[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
#sig

# C18:2n-6c
tapply(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.2n.6c,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.2n.6c[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C18:3n-3
tapply(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.3n.3,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.3n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:3n-6
tapply(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C18.3n.6,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="T"],total_FAs_rel$C18.3n.6[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C20:2n-6
tapply(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.2n.6,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.2n.6[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C20:3n-3
tapply(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.3n.3,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.3n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:4n-6
tapply(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.4n.6,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.4n.6[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:5n-3
tapply(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C20.5n.3,total_FAs_rel$Treatment)

wilcox.test(total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C20.5n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C22:6n-3
tapply(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="C"])
qqPlot(total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(total_FAs_rel$C22.6n.3,total_FAs_rel$Treatment)

t.test(total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="T"],total_FAs_rel$C22.6n.3[total_FAs_rel$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)




SAFA_sum<-subset(total_FAs_rel,select=c("C15.0","C16.0","C17.0","C18.0","C20.0","C22.0","C23.0","C24.0"))
SAFA_sum<-rowSums(SAFA_sum)
SAFA_sum<-cbind(total_FAs_rel[,c(3,4)],SAFA_sum)

tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="C"])
qqPlot(SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(SAFA_sum$SAFA_sum,SAFA_sum$Treatment)

t.test(SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="T"],SAFA_sum$SAFA_sum[SAFA_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

medians_SAFA_sum<-tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,median)
lower_SAFA_sum<-tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_SAFA_sum<-tapply(SAFA_sum$SAFA_sum,SAFA_sum$Treatment,function(x) ci.median(x)$ci[3])

par(mar=c(5, 6.5, 2, 4) + 0.1,xpd=FALSE)
x<-c(1,2)
plotCI(x,medians_SAFA_sum,ui=upper_SAFA_sum,li=lower_SAFA_sum,ylim=c(0,40),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,10,20,30,40),labels=c(0,10,20,30,40),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Relative SAFA content in %",at=20,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)


MUFA_sum<-subset(total_FAs_rel,select=c("C16.1n.7","C18.1n.7","C18.1n.9c","C20.1n.9"))
MUFA_sum<-rowSums(MUFA_sum)
MUFA_sum<-cbind(total_FAs_rel[,c(3,4)],MUFA_sum)

tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="C"])
qqPlot(MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(MUFA_sum$MUFA_sum,MUFA_sum$Treatment)

wilcox.test(MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="T"],MUFA_sum$MUFA_sum[MUFA_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

medians_MUFA_sum<-tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,median)
lower_MUFA_sum<-tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_MUFA_sum<-tapply(MUFA_sum$MUFA_sum,MUFA_sum$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_MUFA_sum,ui=upper_MUFA_sum,li=lower_MUFA_sum,ylim=c(0,40),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,10,20,30,40),labels=c(0,10,20,30,40),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Relative MUFA content in %",at=20,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

PUFA_sum<-subset(total_FAs_rel,select=c("C18.2n.6c","C18.3n.3","C18.3n.6","C20.2n.6","C20.3n.3","C20.4n.6","C20.5n.3","C22.6n.3"))
PUFA_sum<-rowSums(PUFA_sum)
PUFA_sum<-cbind(total_FAs_rel[,c(3,4)],PUFA_sum)

tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="C"])
qqPlot(PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(PUFA_sum$PUFA_sum,PUFA_sum$Treatment)

t.test(PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="T"],PUFA_sum$PUFA_sum[PUFA_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

medians_PUFA_sum<-tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,median)
lower_PUFA_sum<-tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_PUFA_sum<-tapply(PUFA_sum$PUFA_sum,PUFA_sum$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_PUFA_sum,ui=upper_PUFA_sum,li=lower_PUFA_sum,ylim=c(0,60),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,10,20,30,40,50,60),labels=c(0,10,20,30,40,50,60),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Relative PUFA content in %",at=30,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)


#### Total FA
Biofilm2_sum<-rowSums(Biofilm2_ohneTR)
Biofilm2_sum<-cbind(Biofilm2[,c(1,2,3,4)],Biofilm2_sum)
boxplot(Biofilm2_sum~Treatment,Biofilm2_sum)

mean_sum.C<-tapply(Biofilm2_sum$Biofilm2_sum[Biofilm2_sum$Treatment=="C"],Biofilm2_sum$Run[Biofilm2_sum$Treatment=="C"],mean)
mean_sum.T<-tapply(Biofilm2_sum$Biofilm2_sum[Biofilm2_sum$Treatment=="T"],Biofilm2_sum$Run[Biofilm2_sum$Treatment=="T"],mean)
upper_sum.C<-tapply(Biofilm2_sum$Biofilm2_sum[Biofilm2_sum$Treatment=="C"],Biofilm2_sum$Run[Biofilm2_sum$Treatment=="C"],function(x) t.test(x)$conf.int[2])
upper_sum.T<-tapply(Biofilm2_sum$Biofilm2_sum[Biofilm2_sum$Treatment=="T"],Biofilm2_sum$Run[Biofilm2_sum$Treatment=="T"],function(x) t.test(x)$conf.int[2])
lower_sum.C<-tapply(Biofilm2_sum$Biofilm2_sum[Biofilm2_sum$Treatment=="C"],Biofilm2_sum$Run[Biofilm2_sum$Treatment=="C"],function(x) t.test(x)$conf.int[1])
lower_sum.T<-tapply(Biofilm2_sum$Biofilm2_sum[Biofilm2_sum$Treatment=="T"],Biofilm2_sum$Run[Biofilm2_sum$Treatment=="T"],function(x) t.test(x)$conf.int[1])

mean_sum<-c(mean_sum.C[1],mean_sum.T[1],mean_sum.C[2],mean_sum.T[2],mean_sum.C[3],mean_sum.T[3])
upper_sum<-c(upper_sum.C[1],upper_sum.T[1],upper_sum.C[2],upper_sum.T[2],upper_sum.C[3],upper_sum.T[3])
lower_sum<-c(lower_sum.C[1],lower_sum.T[1],lower_sum.C[2],lower_sum.T[2],lower_sum.C[3],lower_sum.T[3])

x<-c(1,1.2,2,2.2,3,3.2)
plotCI(x,mean_sum,ui=upper_sum,li=lower_sum,ylim=c(0,70),xlim=c(1,3.2),xaxt = "n",las=1,yaxs="i",pch=15,col=c("black","red"),ylab=expression("sum FA in �g/mg"),xlab="Treatment")
axis(1,at=c(1,1.2,2,2.2,3,3.2),labels=c("C","T","C","T","C","T"),tick=TRUE)
text(1.1,65,"1. Run")
text(2.1,65,"2. Run")
text(3.1,65,"3. Run")


#### SAFA
Biofilm2_SAFA<-rowSums(Biofilm2_ohneTR[,c("C15.0","C16.0","C17.0","C18.0","C20.0","C22.0","C23.0","C24.0")])
Biofilm2_SAFA<-cbind(Biofilm2[,c(1,2,3,4)],Biofilm2_SAFA)

anovaSAFA<-aov(Biofilm2_SAFA~Run*Treatment,Biofilm2_SAFA)
qqPlot(anovaSAFA$residuals)
shapiro.test(anovaSAFA$residuals)
leveneTest(Biofilm2_SAFA$Biofilm2_SAFA,interaction(Biofilm2_SAFA$Run,Biofilm2_SAFA$Treatment))
summary(anovaSAFA)

mean_SAFA.C<-tapply(Biofilm2_SAFA$Biofilm2_SAFA[Biofilm2_SAFA$Treatment=="C"],Biofilm2_SAFA$Run[Biofilm2_SAFA$Treatment=="C"],mean)
mean_SAFA.T<-tapply(Biofilm2_SAFA$Biofilm2_SAFA[Biofilm2_SAFA$Treatment=="T"],Biofilm2_SAFA$Run[Biofilm2_SAFA$Treatment=="T"],mean)
upper_SAFA.C<-tapply(Biofilm2_SAFA$Biofilm2_SAFA[Biofilm2_SAFA$Treatment=="C"],Biofilm2_SAFA$Run[Biofilm2_SAFA$Treatment=="C"],function(x) t.test(x)$conf.int[2])
upper_SAFA.T<-tapply(Biofilm2_SAFA$Biofilm2_SAFA[Biofilm2_SAFA$Treatment=="T"],Biofilm2_SAFA$Run[Biofilm2_SAFA$Treatment=="T"],function(x) t.test(x)$conf.int[2])
lower_SAFA.C<-tapply(Biofilm2_SAFA$Biofilm2_SAFA[Biofilm2_SAFA$Treatment=="C"],Biofilm2_SAFA$Run[Biofilm2_SAFA$Treatment=="C"],function(x) t.test(x)$conf.int[1])
lower_SAFA.T<-tapply(Biofilm2_SAFA$Biofilm2_SAFA[Biofilm2_SAFA$Treatment=="T"],Biofilm2_SAFA$Run[Biofilm2_SAFA$Treatment=="T"],function(x) t.test(x)$conf.int[1])

mean_SAFA<-c(mean_SAFA.C[1],mean_SAFA.T[1],mean_SAFA.C[2],mean_SAFA.T[2],mean_SAFA.C[3],mean_SAFA.T[3])
upper_SAFA<-c(upper_SAFA.C[1],upper_SAFA.T[1],upper_SAFA.C[2],upper_SAFA.T[2],upper_SAFA.C[3],upper_SAFA.T[3])
lower_SAFA<-c(lower_SAFA.C[1],lower_SAFA.T[1],lower_SAFA.C[2],lower_SAFA.T[2],lower_SAFA.C[3],lower_SAFA.T[3])

x<-c(1,1.2,2,2.2,3,3.2)
plotCI(x,mean_SAFA,ui=upper_SAFA,li=lower_SAFA,ylim=c(0,20),xlim=c(1,3.2),xaxt = "n",las=1,yaxs="i",pch=15,col=c("black","red"),ylab=expression("SAFAs in �g/mg"),xlab="Treatment")
axis(1,at=c(1,1.2,2,2.2,3,3.2),labels=c("C","T","C","T","C","T"),tick=TRUE)
text(1.1,14,"1. Run")
text(2.1,14,"2. Run")
text(3.1,14,"3. Run")

#### MUFA
Biofilm2_MUFA<-rowSums(Biofilm2_ohneTR[,c("C16.1n.7","C18.1n.7","C18.1n.9c","C20.1n.9")])
Biofilm2_MUFA<-cbind(Biofilm2[,c(1,2,3,4)],Biofilm2_MUFA)

anovaMUFA<-aov(Biofilm2_MUFA~Run*Treatment,Biofilm2_MUFA)
qqPlot(anovaMUFA$residuals)
shapiro.test(anovaMUFA$residuals)
leveneTest(Biofilm2_MUFA$Biofilm2_MUFA,interaction(Biofilm2_MUFA$Run,Biofilm2_MUFA$Treatment))
summary(anovaMUFA)

mean_MUFA.C<-tapply(Biofilm2_MUFA$Biofilm2_MUFA[Biofilm2_MUFA$Treatment=="C"],Biofilm2_MUFA$Run[Biofilm2_MUFA$Treatment=="C"],mean)
mean_MUFA.T<-tapply(Biofilm2_MUFA$Biofilm2_MUFA[Biofilm2_MUFA$Treatment=="T"],Biofilm2_MUFA$Run[Biofilm2_MUFA$Treatment=="T"],mean)
upper_MUFA.C<-tapply(Biofilm2_MUFA$Biofilm2_MUFA[Biofilm2_MUFA$Treatment=="C"],Biofilm2_MUFA$Run[Biofilm2_MUFA$Treatment=="C"],function(x) t.test(x)$conf.int[2])
upper_MUFA.T<-tapply(Biofilm2_MUFA$Biofilm2_MUFA[Biofilm2_MUFA$Treatment=="T"],Biofilm2_MUFA$Run[Biofilm2_MUFA$Treatment=="T"],function(x) t.test(x)$conf.int[2])
lower_MUFA.C<-tapply(Biofilm2_MUFA$Biofilm2_MUFA[Biofilm2_MUFA$Treatment=="C"],Biofilm2_MUFA$Run[Biofilm2_MUFA$Treatment=="C"],function(x) t.test(x)$conf.int[1])
lower_MUFA.T<-tapply(Biofilm2_MUFA$Biofilm2_MUFA[Biofilm2_MUFA$Treatment=="T"],Biofilm2_MUFA$Run[Biofilm2_MUFA$Treatment=="T"],function(x) t.test(x)$conf.int[1])

mean_MUFA<-c(mean_MUFA.C[1],mean_MUFA.T[1],mean_MUFA.C[2],mean_MUFA.T[2],mean_MUFA.C[3],mean_MUFA.T[3])
upper_MUFA<-c(upper_MUFA.C[1],upper_MUFA.T[1],upper_MUFA.C[2],upper_MUFA.T[2],upper_MUFA.C[3],upper_MUFA.T[3])
lower_MUFA<-c(lower_MUFA.C[1],lower_MUFA.T[1],lower_MUFA.C[2],lower_MUFA.T[2],lower_MUFA.C[3],lower_MUFA.T[3])

x<-c(1,1.2,2,2.2,3,3.2)
plotCI(x,mean_MUFA,ui=upper_MUFA,li=lower_MUFA,ylim=c(0,12),xlim=c(1,3.2),xaxt = "n",las=1,yaxs="i",pch=15,col=c("black","red"),ylab=expression("MUFAs in �g/mg"),xlab="Treatment")
axis(1,at=c(1,1.2,2,2.2,3,3.2),labels=c("C","T","C","T","C","T"),tick=TRUE)
text(1.1,11.5,"1. Run")
text(2.1,11.5,"2. Run")
text(3.1,11.5,"3. Run")

#### PUFA
Biofilm2_PUFA<-rowSums(Biofilm2_ohneTR[,c("C18.2n.6c","C18.3n.3","C18.3n.6","C20.2n.6","C20.3n.3","C20.4n.6","C20.5n.3","C22.6n.3")])
Biofilm2_PUFA<-cbind(Biofilm2[,c(1,2,3,4)],Biofilm2_PUFA)

anovaPUFA<-aov(Biofilm2_PUFA~Run*Treatment,Biofilm2_PUFA)
qqPlot(anovaPUFA$residuals)
shapiro.test(anovaPUFA$residuals)
leveneTest(Biofilm2_PUFA$Biofilm2_PUFA,interaction(Biofilm2_PUFA$Run,Biofilm2_PUFA$Treatment))
summary(anovaPUFA)

mean_PUFA.C<-tapply(Biofilm2_PUFA$Biofilm2_PUFA[Biofilm2_PUFA$Treatment=="C"],Biofilm2_PUFA$Run[Biofilm2_PUFA$Treatment=="C"],mean)
mean_PUFA.T<-tapply(Biofilm2_PUFA$Biofilm2_PUFA[Biofilm2_PUFA$Treatment=="T"],Biofilm2_PUFA$Run[Biofilm2_PUFA$Treatment=="T"],mean)
upper_PUFA.C<-tapply(Biofilm2_PUFA$Biofilm2_PUFA[Biofilm2_PUFA$Treatment=="C"],Biofilm2_PUFA$Run[Biofilm2_PUFA$Treatment=="C"],function(x) t.test(x)$conf.int[2])
upper_PUFA.T<-tapply(Biofilm2_PUFA$Biofilm2_PUFA[Biofilm2_PUFA$Treatment=="T"],Biofilm2_PUFA$Run[Biofilm2_PUFA$Treatment=="T"],function(x) t.test(x)$conf.int[2])
lower_PUFA.C<-tapply(Biofilm2_PUFA$Biofilm2_PUFA[Biofilm2_PUFA$Treatment=="C"],Biofilm2_PUFA$Run[Biofilm2_PUFA$Treatment=="C"],function(x) t.test(x)$conf.int[1])
lower_PUFA.T<-tapply(Biofilm2_PUFA$Biofilm2_PUFA[Biofilm2_PUFA$Treatment=="T"],Biofilm2_PUFA$Run[Biofilm2_PUFA$Treatment=="T"],function(x) t.test(x)$conf.int[1])

mean_PUFA<-c(mean_PUFA.C[1],mean_PUFA.T[1],mean_PUFA.C[2],mean_PUFA.T[2],mean_PUFA.C[3],mean_PUFA.T[3])
upper_PUFA<-c(upper_PUFA.C[1],upper_PUFA.T[1],upper_PUFA.C[2],upper_PUFA.T[2],upper_PUFA.C[3],upper_PUFA.T[3])
lower_PUFA<-c(lower_PUFA.C[1],lower_PUFA.T[1],lower_PUFA.C[2],lower_PUFA.T[2],lower_PUFA.C[3],lower_PUFA.T[3])

x<-c(1,1.2,2,2.2,3,3.2)
plotCI(x,mean_PUFA,ui=upper_PUFA,li=lower_PUFA,ylim=c(0,35),xlim=c(1,3.2),xaxt = "n",las=1,yaxs="i",pch=15,col=c("black","red"),ylab=expression("PUFAs in �g/mg"),xlab="Treatment")
axis(1,at=c(1,1.2,2,2.2,3,3.2),labels=c("C","T","C","T","C","T"),tick=TRUE)
text(1.1,32.5,"1. Run")
text(2.1,32.5,"2. Run")
text(3.1,32.5,"3. Run")


#### HUFA
Biofilm2_HUFA<-rowSums(Biofilm2_ohneTR[,c("C20.2n.6","C20.3n.3","C20.4n.6","C20.5n.3","C22.6n.3")])
Biofilm2_HUFA<-cbind(Biofilm2[,c(1,2,3,4)],Biofilm2_HUFA)

anovaHUFA<-aov(Biofilm2_HUFA~Run*Treatment,Biofilm2_HUFA)
qqPlot(anovaHUFA$residuals)
shapiro.test(anovaHUFA$residuals)
leveneTest(Biofilm2_HUFA$Biofilm2_HUFA,interaction(Biofilm2_HUFA$Run,Biofilm2_HUFA$Treatment))
summary(anovaHUFA)

mean_HUFA.C<-tapply(Biofilm2_HUFA$Biofilm2_HUFA[Biofilm2_HUFA$Treatment=="C"],Biofilm2_HUFA$Run[Biofilm2_HUFA$Treatment=="C"],mean)
mean_HUFA.T<-tapply(Biofilm2_HUFA$Biofilm2_HUFA[Biofilm2_HUFA$Treatment=="T"],Biofilm2_HUFA$Run[Biofilm2_HUFA$Treatment=="T"],mean)
upper_HUFA.C<-tapply(Biofilm2_HUFA$Biofilm2_HUFA[Biofilm2_HUFA$Treatment=="C"],Biofilm2_HUFA$Run[Biofilm2_HUFA$Treatment=="C"],function(x) t.test(x)$conf.int[2])
upper_HUFA.T<-tapply(Biofilm2_HUFA$Biofilm2_HUFA[Biofilm2_HUFA$Treatment=="T"],Biofilm2_HUFA$Run[Biofilm2_HUFA$Treatment=="T"],function(x) t.test(x)$conf.int[2])
lower_HUFA.C<-tapply(Biofilm2_HUFA$Biofilm2_HUFA[Biofilm2_HUFA$Treatment=="C"],Biofilm2_HUFA$Run[Biofilm2_HUFA$Treatment=="C"],function(x) t.test(x)$conf.int[1])
lower_HUFA.T<-tapply(Biofilm2_HUFA$Biofilm2_HUFA[Biofilm2_HUFA$Treatment=="T"],Biofilm2_HUFA$Run[Biofilm2_HUFA$Treatment=="T"],function(x) t.test(x)$conf.int[1])

mean_HUFA<-c(mean_HUFA.C[1],mean_HUFA.T[1],mean_HUFA.C[2],mean_HUFA.T[2],mean_HUFA.C[3],mean_HUFA.T[3])
upper_HUFA<-c(upper_HUFA.C[1],upper_HUFA.T[1],upper_HUFA.C[2],upper_HUFA.T[2],upper_HUFA.C[3],upper_HUFA.T[3])
lower_HUFA<-c(lower_HUFA.C[1],lower_HUFA.T[1],lower_HUFA.C[2],lower_HUFA.T[2],lower_HUFA.C[3],lower_HUFA.T[3])

x<-c(1,1.2,2,2.2,3,3.2)
plotCI(x,mean_HUFA,ui=upper_HUFA,li=lower_HUFA,ylim=c(0,4),xlim=c(1,3.2),xaxt = "n",las=1,yaxs="i",pch=15,col=c("black","red"),ylab=expression("HUFAs in �g/mg"),xlab="Treatment")
axis(1,at=c(1,1.2,2,2.2,3,3.2),labels=c("C","T","C","T","C","T"),tick=TRUE)
text(1.1,3.75,"1. Run")
text(2.1,3.75,"2. Run")
text(3.1,3.75,"3. Run")


#### Table: absolut FAs

MediansCIs<- data.frame(matrix(nrow = ncol(Biofilm2_ohneTR)*ncol(Biofilm2_ohneTR)+ncol(Biofilm2_ohneTR)+1, ncol = 6))
colnames(MediansCIs) <- c("Name","Treatment","Median", "lower CI","to","upper CI")
for(i in 1:ncol(Biofilm2_ohneTR))
{
  Medians  <-tapply(Biofilm2_ohneTR[[i]],total_FAs_rel$Treatment,median)
  CIs_lower<-tapply(Biofilm2_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[1])
  CIs_upper<-tapply(Biofilm2_ohneTR[[i]],total_FAs_rel$Treatment,function(x) wilcox.test(x,alternative="two.sided",correct=TRUE,conf.int=TRUE,conf.level=0.95)$conf.int[2])

  MediansCIs[i*i+i, 1] <- Names[i]
  MediansCIs[i*i+i, 2] <- "Control"
  MediansCIs[i*i+i, 3] <- unname(Medians[!is.na(Medians)])[1]
  MediansCIs[i*i+i, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[1]
  MediansCIs[i*i+i, 5] <- "to"
  MediansCIs[i*i+i, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[1]

  MediansCIs[i*i+i+1, 1] <- Names[i]
  MediansCIs[i*i+i+1, 2] <- "Treatment"
  MediansCIs[i*i+i+1, 3] <- unname(Medians[!is.na(Medians)])[2]
  MediansCIs[i*i+i+1, 4] <- unname(CIs_lower[!is.na(CIs_lower)])[2]
  MediansCIs[i*i+i+1, 5] <- "to"
  MediansCIs[i*i+i+1, 6] <- unname(CIs_upper[!is.na(CIs_upper)])[2]

}

MediansCIs<-subset(MediansCIs,! Name %in% NA)
MediansCIs[,c(3,4,6)]<-round(MediansCIs[,c(3,4,6)],2)
MediansCIs$M_CIs<-with(MediansCIs, paste0(`Median`," ","(",`lower CI`," " ,`to`," " ,`upper CI`,")" ))
MediansCIs<-MediansCIs[,-c(3,4,5,6)]
MediansCIs_C<-subset(MediansCIs,! Treatment %in% "Treatment")
MediansCIs_T<-subset(MediansCIs,Treatment %in% "Treatment")
MediansCIs<-cbind(MediansCIs_C,MediansCIs_T)
MediansCIs<-MediansCIs[,-c(2,4,5)]
colnames(MediansCIs)[2] <- "Control"
colnames(MediansCIs)[3] <- "Diuron"
#write.table(MediansCIs, file = "Grazer study-absolut FAs of biofilm.txt", sep="\t")


# Univariat ABSOLUT

PPFD<-subset(Parameters,select = c(Run,Treatment,Replicate,PhotoActRad))

Biofilm_PPFD<-merge(Biofilm2, PPFD, by = c("Run","Treatment", "Replicate"))
Biofilm_PPFD<-Biofilm_PPFD[order(Treatment),]

# C15:0
# leveneTest(Biofilm_PPFD$C15.0,Biofilm_PPFD$Treatment)

# AV_C15.0_Slopes<-aov(C15.0~PhotoActRad*Treatment,Biofilm_PPFD)
# summary(AV_C15.0_Slopes)
#
# plot(Biofilm_PPFD$PhotoActRad[Biofilm_PPFD$Treatment=="C"],Biofilm_PPFD$C15.0[Biofilm_PPFD$Treatment=="C"],xlab="Light",ylab="15:0 �g/mg")
# abline(lm(Biofilm_PPFD$C15.0[Biofilm_PPFD$Treatment=="C"]~Biofilm_PPFD$PhotoActRad[Biofilm_PPFD$Treatment=="C"]))
# par(new=TRUE)
# plot(Biofilm_PPFD$PhotoActRad[Biofilm_PPFD$Treatment=="T"],Biofilm_PPFD$C15.0[Biofilm_PPFD$Treatment=="T"],pch=16,axes = FALSE,xlab="",ylab="")
# abline(lm(Biofilm_PPFD$C15.0[Biofilm_PPFD$Treatment=="T"]~Biofilm_PPFD$PhotoActRad[Biofilm_PPFD$Treatment=="T"]),lty=2)
#
# multReg_C15.0<-lm(C15.0~PhotoActRad*Treatment,data=Biofilm_PPFD)
# shapiro.test(multReg_C15.0$residuals)
# bptest(multReg_C15.0) #  Breusch-Pagan test against heteroskedasticity for lm()
# 1/vif(multReg_C15.0) #  multicollinearity ist gegeben
# mean(vif(multReg_C15.0)) #  multicollinearity ist gegeben

tapply(Biofilm2$C15.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C15.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C15.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C15.0,Biofilm2$Treatment)

t.test(Biofilm2$C15.0[Biofilm2$Treatment=="T"],Biofilm2$C15.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# Tendenz

# C16:0
tapply(Biofilm2$C16.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C16.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C16.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C16.0,Biofilm2$Treatment)

t.test(Biofilm2$C16.0[Biofilm2$Treatment=="T"],Biofilm2$C16.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C17:0
tapply(Biofilm2$C17.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C17.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C17.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C17.0,Biofilm2$Treatment)

t.test(Biofilm2$C17.0[Biofilm2$Treatment=="T"],Biofilm2$C17.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C18:0
tapply(Biofilm2$C18.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C18.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C18.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C18.0,Biofilm2$Treatment)

wilcox.test(Biofilm2$C18.0[Biofilm2$Treatment=="T"],Biofilm2$C18.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:0
tapply(Biofilm2$C20.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C20.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C20.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C20.0,Biofilm2$Treatment)

wilcox.test(Biofilm2$C20.0[Biofilm2$Treatment=="T"],Biofilm2$C20.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C22:0
tapply(Biofilm2$C22.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C22.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C22.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C22.0,Biofilm2$Treatment)

wilcox.test(Biofilm2$C22.0[Biofilm2$Treatment=="T"],Biofilm2$C22.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C23:0
tapply(Biofilm2$C23.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C23.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C23.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C23.0,Biofilm2$Treatment)

t.test(Biofilm2$C23.0[Biofilm2$Treatment=="T"],Biofilm2$C23.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C24:0
tapply(Biofilm2$C24.0,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C24.0[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C24.0[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C24.0,Biofilm2$Treatment)

wilcox.test(Biofilm2$C24.0[Biofilm2$Treatment=="T"],Biofilm2$C24.0[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C16:1n-7
tapply(Biofilm2$C16.1n.7,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C16.1n.7[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C16.1n.7[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C16.1n.7,Biofilm2$Treatment)

t.test(Biofilm2$C16.1n.7[Biofilm2$Treatment=="T"],Biofilm2$C16.1n.7[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:1n-7
tapply(Biofilm2$C18.1n.7,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C18.1n.7[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C18.1n.7[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C18.1n.7,Biofilm2$Treatment)

t.test(Biofilm2$C18.1n.7[Biofilm2$Treatment=="T"],Biofilm2$C18.1n.7[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

# C18:1n-9
tapply(Biofilm2$C18.1n.9c,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C18.1n.9c[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C18.1n.9c[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C18.1n.9c,Biofilm2$Treatment)

wilcox.test(Biofilm2$C18.1n.9c[Biofilm2$Treatment=="T"],Biofilm2$C18.1n.9c[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:1n-9
tapply(Biofilm2$C20.1n.9,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C20.1n.9[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C20.1n.9[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C20.1n.9,Biofilm2$Treatment)

t.test(Biofilm2$C20.1n.9[Biofilm2$Treatment=="T"],Biofilm2$C20.1n.9[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C18:2n-6c
tapply(Biofilm2$C18.2n.6c,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C18.2n.6c[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C18.2n.6c[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C18.2n.6c,Biofilm2$Treatment)

t.test(Biofilm2$C18.2n.6c[Biofilm2$Treatment=="T"],Biofilm2$C18.2n.6c[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C18:3n-3
tapply(Biofilm2$C18.3n.3,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C18.3n.3[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C18.3n.3[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C18.3n.3,Biofilm2$Treatment)

t.test(Biofilm2$C18.3n.3[Biofilm2$Treatment=="T"],Biofilm2$C18.3n.3[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C18:3n-6
tapply(Biofilm2$C18.3n.6,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C18.3n.6[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C18.3n.6[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C18.3n.6,Biofilm2$Treatment)

t.test(Biofilm2$C18.3n.6[Biofilm2$Treatment=="T"],Biofilm2$C18.3n.6[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C20:2n-6
tapply(Biofilm2$C20.2n.6,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C20.2n.6[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C20.2n.6[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C20.2n.6,Biofilm2$Treatment)

t.test(Biofilm2$C20.2n.6[Biofilm2$Treatment=="T"],Biofilm2$C20.2n.6[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# C20:3n-3
tapply(Biofilm2$C20.3n.3,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C20.3n.3[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C20.3n.3[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C20.3n.3,Biofilm2$Treatment)

wilcox.test(Biofilm2$C20.3n.3[Biofilm2$Treatment=="T"],Biofilm2$C20.3n.3[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:4n-6
tapply(Biofilm2$C20.4n.6,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C20.4n.6[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C20.4n.6[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C20.4n.6,Biofilm2$Treatment)

wilcox.test(Biofilm2$C20.4n.6[Biofilm2$Treatment=="T"],Biofilm2$C20.4n.6[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

# C20:5n-3
tapply(Biofilm2$C20.5n.3,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C20.5n.3[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C20.5n.3[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C20.5n.3,Biofilm2$Treatment)

wilcox.test(Biofilm2$C20.5n.3[Biofilm2$Treatment=="T"],Biofilm2$C20.5n.3[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)

# C22:6n-3
tapply(Biofilm2$C22.6n.3,Biofilm2$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm2$C22.6n.3[Biofilm2$Treatment=="C"])
qqPlot(Biofilm2$C22.6n.3[Biofilm2$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm2$C22.6n.3,Biofilm2$Treatment)

t.test(Biofilm2$C22.6n.3[Biofilm2$Treatment=="T"],Biofilm2$C22.6n.3[Biofilm2$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)

# Biofilm2_sum
Biofilm_PPFD_ohneTR<-subset(Biofilm_PPFD,select = -c(Run,Treatment,Replicate,RUNINFO,PhotoActRad))
B_sum<-rowSums(Biofilm_PPFD_ohneTR)
Biofilm_PPFD_sum<-cbind(Biofilm_PPFD[,c(2,24)],B_sum)

# leveneTest(Biofilm_PPFD_sum$B_sum,Biofilm_PPFD_sum$Treatment)

# AV_B_sum_Slopes<-aov(B_sum~PhotoActRad*Treatment,Biofilm_PPFD_sum)
# summary(AV_B_sum_Slopes)
# AV_B_sum<-aov(B_sum~PhotoActRad+Treatment,Biofilm_PPFD_sum)
# shapiro.test(AV_B_sum$residuals)
# summary(AV_B_sum) # sig.
#plot(AV_B_sum)

tapply(Biofilm_PPFD_sum$B_sum,Biofilm_PPFD_sum$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm_PPFD_sum$B_sum[Biofilm_PPFD_sum$Treatment=="C"])
qqPlot(Biofilm_PPFD_sum$B_sum[Biofilm_PPFD_sum$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm_PPFD_sum$B_sum,Biofilm_PPFD_sum$Treatment)

wilcox.test(Biofilm_PPFD_sum$B_sum[Biofilm_PPFD_sum$Treatment=="T"],Biofilm_PPFD_sum$B_sum[Biofilm_PPFD_sum$Treatment=="C"],alternative="two.sided",paired=FALSE,conf.level=1-0.05,conf.int=TRUE)
# sig.

medians_sum2<-tapply(Biofilm_PPFD_sum$B_sum,Biofilm_PPFD_sum$Treatment,median)
lower_sum2<-tapply(Biofilm_PPFD_sum$B_sum,Biofilm_PPFD_sum$Treatment,function(x) ci.median(x)$ci[2])
upper_sum2<-tapply(Biofilm_PPFD_sum$B_sum,Biofilm_PPFD_sum$Treatment,function(x) ci.median(x)$ci[3])

par(mar=c(5, 6.5, 2, 4) + 0.1,xpd=FALSE)
x<-c(1,2)
plotCI(x,medians_sum2,ui=upper_sum2,li=lower_sum2,ylim=c(0,35),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,5,10,15,20,25,30,35),labels=c(0,5,10,15,20,25,30,35),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("Fatty acid content in �g/mg biofilm",at=17.5,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

# Biofilm2_SAFA
B_SAFA<-rowSums(Biofilm_PPFD_ohneTR[,c("C15.0","C16.0","C17.0","C18.0","C20.0","C22.0","C23.0","C24.0")])
Biofilm_PPFD_SAFA<-cbind(Biofilm_PPFD[,c(2,24)],B_SAFA)

# leveneTest(Biofilm_PPFD_SAFA$B_SAFA,Biofilm_PPFD_SAFA$Treatment)
#
# AV_SAFA_Slopes<-aov(B_SAFA~PhotoActRad*Treatment,Biofilm_PPFD_SAFA)
# summary(AV_SAFA_Slopes)
# AV_SAFA<-aov(B_SAFA~PhotoActRad+Treatment,Biofilm_PPFD_SAFA)
# shapiro.test(AV_SAFA$residuals)
# summary(AV_SAFA) # sig.
#plot(AV_SAFA)

tapply(Biofilm_PPFD_SAFA$B_SAFA,Biofilm_PPFD_SAFA$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm_PPFD_SAFA$B_SAFA[Biofilm_PPFD_SAFA$Treatment=="C"])
qqPlot(Biofilm_PPFD_SAFA$B_SAFA[Biofilm_PPFD_SAFA$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm_PPFD_SAFA$B_SAFA,Biofilm_PPFD_SAFA$Treatment)

t.test(Biofilm_PPFD_SAFA$B_SAFA[Biofilm_PPFD_SAFA$Treatment=="T"],Biofilm_PPFD_SAFA$B_SAFA[Biofilm_PPFD_SAFA$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

medians_SAFA2<-tapply(Biofilm_PPFD_SAFA$B_SAFA,Biofilm_PPFD_SAFA$Treatment,median)
lower_SAFA2<-tapply(Biofilm_PPFD_SAFA$B_SAFA,Biofilm_PPFD_SAFA$Treatment,function(x) ci.median(x)$ci[2])
upper_SAFA2<-tapply(Biofilm_PPFD_SAFA$B_SAFA,Biofilm_PPFD_SAFA$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_SAFA2,ui=upper_SAFA2,li=lower_SAFA2,ylim=c(0,10),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,2,4,6,8,10),labels=c(0,2,4,6,8,10),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("SAFA content in �g/mg",at=5,side=2,line=4,cex=1.5)
lines(c(-0.15,3),c(0,0),type="l",lty=1,lwd=1.5)

# Biofilm2_MUFA
B_MUFA<-rowSums(Biofilm_PPFD_ohneTR[,c("C16.1n.7","C18.1n.7","C18.1n.9c","C20.1n.9")])
Biofilm_PPFD_MUFA<-cbind(Biofilm_PPFD[,c(2,24)],B_MUFA)

# leveneTest(Biofilm_PPFD_MUFA$B_MUFA,Biofilm_PPFD_MUFA$Treatment)
#
# AV_MUFA_Slopes<-aov(B_MUFA~PhotoActRad*Treatment,Biofilm_PPFD_MUFA)
# summary(AV_MUFA_Slopes)
# AV_MUFA<-aov(B_MUFA~PhotoActRad+Treatment,Biofilm_PPFD_MUFA)
# shapiro.test(AV_MUFA$residuals)
# summary(AV_MUFA) # sig.
#plot(AV_MUFA)

tapply(Biofilm_PPFD_MUFA$B_MUFA,Biofilm_PPFD_MUFA$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm_PPFD_MUFA$B_MUFA[Biofilm_PPFD_MUFA$Treatment=="C"])
qqPlot(Biofilm_PPFD_MUFA$B_MUFA[Biofilm_PPFD_MUFA$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm_PPFD_MUFA$B_MUFA,Biofilm_PPFD_MUFA$Treatment)

t.test(Biofilm_PPFD_MUFA$B_MUFA[Biofilm_PPFD_MUFA$Treatment=="T"],Biofilm_PPFD_MUFA$B_MUFA[Biofilm_PPFD_MUFA$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# sig.

medians_MUFA2<-tapply(Biofilm_PPFD_MUFA$B_MUFA,Biofilm_PPFD_MUFA$Treatment,median)
lower_MUFA2<-tapply(Biofilm_PPFD_MUFA$B_MUFA,Biofilm_PPFD_MUFA$Treatment,function(x) ci.median(x)$ci[2])
upper_MUFA2<-tapply(Biofilm_PPFD_MUFA$B_MUFA,Biofilm_PPFD_MUFA$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_MUFA2,ui=upper_MUFA2,li=lower_MUFA2,ylim=c(0,7),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,1,2,3,4,5,6,7),labels=c(0,1,2,3,4,5,6,7),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("MUFA content in �g/mg",at=3.5,side=2,line=4,cex=1.5)
lines(c(-0.1,3),c(0,0),type="l",lty=1,lwd=1.5)

# Biofilm2_PUFA
B_PUFA<-rowSums(Biofilm_PPFD_ohneTR[,c("C18.2n.6c","C18.3n.3","C18.3n.6","C20.2n.6","C20.3n.3","C20.4n.6","C20.5n.3","C22.6n.3")])
Biofilm_PPFD_PUFA<-cbind(Biofilm_PPFD[,c(2,24)],B_PUFA)

# leveneTest(Biofilm_PPFD_PUFA$B_PUFA,Biofilm_PPFD_PUFA$Treatment)
#
# AV_PUFA_Slopes<-aov(B_PUFA~PhotoActRad*Treatment,Biofilm_PPFD_PUFA)
# summary(AV_PUFA_Slopes)
# AV_PUFA<-aov(B_PUFA~PhotoActRad+Treatment,Biofilm_PPFD_PUFA)
# shapiro.test(AV_PUFA$residuals)
# summary(AV_PUFA) # Tendenz
#plot(AV_PUFA)

tapply(Biofilm_PPFD_PUFA$B_PUFA,Biofilm_PPFD_PUFA$Treatment,shapiro.test)

par(mfrow=c(1,2))
qqPlot(Biofilm_PPFD_PUFA$B_PUFA[Biofilm_PPFD_PUFA$Treatment=="C"])
qqPlot(Biofilm_PPFD_PUFA$B_PUFA[Biofilm_PPFD_PUFA$Treatment=="T"])
par(mfrow=c(1,1))

leveneTest(Biofilm_PPFD_PUFA$B_PUFA,Biofilm_PPFD_PUFA$Treatment)

t.test(Biofilm_PPFD_PUFA$B_PUFA[Biofilm_PPFD_PUFA$Treatment=="T"],Biofilm_PPFD_PUFA$B_PUFA[Biofilm_PPFD_PUFA$Treatment=="C"],alternative="two.sided",paired=FALSE,var.equal=TRUE,conf.level=0.95)
# Tendenz

medians_PUFA2<-tapply(Biofilm_PPFD_PUFA$B_PUFA,Biofilm_PPFD_PUFA$Treatment,median)
lower_PUFA2<-tapply(Biofilm_PPFD_PUFA$B_PUFA,Biofilm_PPFD_PUFA$Treatment,function(x) ci.median(x)$ci[2])
upper_PUFA2<-tapply(Biofilm_PPFD_PUFA$B_PUFA,Biofilm_PPFD_PUFA$Treatment,function(x) ci.median(x)$ci[3])

x<-c(1,2)
plotCI(x,medians_PUFA2,ui=upper_PUFA2,li=lower_PUFA2,ylim=c(0,18),xlim=c(0,3),bty="n",las=1,yaxs="i",xaxt="n",yaxt = "n",ylab="",xlab="Diuron in �g/L",pch=16,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(side=1, at=c(1,2), labels=c("0","8"),las=1,cex.axis=1.5,cex.lab=1.5,lwd=1.5)
axis(2,at=c(0,2,4,6,8,10,12,14,16,18),labels=c(0,2,4,6,8,10,12,14,16,18),tick=TRUE,las=1,cex.axis=1.5,lwd=1.5)
mtext("PUFA content in �g/mg",at=9,side=2,line=4,cex=1.5)
lines(c(-0.15,3),c(0,0),type="l",lty=1,lwd=1.5)


#==============================================================
#### Multivariate statistics with & without sqrt transformation
#==============================================================


#### Absolute

Parameters<-Parameters[,c(-1,-2,-3)]
Biofilm2$ID<- with(Biofilm2, paste0(Run, Treatment, Replicate))

Biofilm2_par<-merge(Biofilm2, Parameters[, with = F],  by = "ID")
Biofilm2_par<-Biofilm2_par[order(Treatment),]

Parameters_mult<-subset(Biofilm2_par,select=c(Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
PhotoActRads<-Parameters_mult$PhotoActRad
Velocities<-Parameters_mult$Velocity
pHs<-Parameters_mult$pH
O2s<-Parameters_mult$O2
Conductivities<-Parameters_mult$Conductivity

Biofilm_MULT<-subset(Biofilm2_par,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))

FAs_mult<-sqrt(Biofilm_MULT)

# Outlier detection
#library(mvoutlier)
aq.plot(FAs_mult[,-c(11,12,13,14,17)])

# Assumption for applying PERMANOVA (=> gleiche Streuung innerhalb der Gruppen)
bd <- betadisper(vegdist(FAs_mult), Biofilm2_par$Treatment)
permutest(bd)

bd <- betadisper(vegdist(FAs_mult), Biofilm2_par$Run)
permutest(bd) # significant !!!

ad <- adonis2(FAs_mult ~ Biofilm2_par$Treatment * Biofilm2_par$Run)
ad # sig.


# SIMPER (similarity percentage analysis)
simper <- simper(FAs_mult, Treatments)
summary(simper)


# Colonization phases
# Phase 1
Biofilm2_par.R1<-subset(Biofilm2_par, Run %in% "R1")
Biofilm_MULT.R1<-subset(Biofilm2_par.R1,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
FAs_mult.R1<-sqrt(Biofilm_MULT.R1)

bd <- betadisper(vegdist(FAs_mult.R1), Biofilm2_par.R1$Treatment)
permutest(bd)


ad <- adonis2(FAs_mult.R1 ~ Biofilm2_par.R1$Treatment)
ad

# Phase 2
Biofilm2_par.R2<-subset(Biofilm2_par, Run %in% "R2")
Biofilm_MULT.R2<-subset(Biofilm2_par.R2,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
FAs_mult.R2<-sqrt(Biofilm_MULT.R2)

bd <- betadisper(vegdist(FAs_mult.R2), Biofilm2_par.R2$Treatment)
permutest(bd)


ad <- adonis2(FAs_mult.R2 ~ Biofilm2_par.R2$Treatment)
ad

# Phase 3
Biofilm2_par.R3<-subset(Biofilm2_par, Run %in% "R3")
Biofilm_MULT.R3<-subset(Biofilm2_par.R3,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
FAs_mult.R3<-sqrt(Biofilm_MULT.R3)

bd <- betadisper(vegdist(FAs_mult.R3), Biofilm2_par.R3$Treatment)
permutest(bd)


ad <- adonis2(FAs_mult.R3 ~ Biofilm2_par.R3$Treatment)
ad

# Phase 1 vs phase 2
Biofilm2_par.R1vsR2<-subset(Biofilm2_par, Run %in% c("R1","R2"))
Biofilm_MULT.R1vsR2<-subset(Biofilm2_par.R1vsR2,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
FAs_mult.R1vsR2<-sqrt(Biofilm_MULT.R1vsR2)

bd <- betadisper(vegdist(FAs_mult.R1vsR2), Biofilm2_par.R1vsR2$Run)
permutest(bd)


ad <- adonis2(FAs_mult.R1vsR2 ~ Biofilm2_par.R1vsR2$Run)
ad

# Phase 1 vs phase 3
Biofilm2_par.R1vsR3<-subset(Biofilm2_par, Run %in% c("R1","R3"))
Biofilm_MULT.R1vsR3<-subset(Biofilm2_par.R1vsR3,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
FAs_mult.R1vsR3<-sqrt(Biofilm_MULT.R1vsR3)

bd <- betadisper(vegdist(FAs_mult.R1vsR3), Biofilm2_par.R1vsR3$Run)
permutest(bd)

ad <- adonis2(FAs_mult.R1vsR3 ~ Biofilm2_par.R1vsR3$Run)
ad

# Phase 2 vs phase 3
Biofilm2_par.R2vsR3<-subset(Biofilm2_par, Run %in% c("R2","R3"))
Biofilm_MULT.R2vsR3<-subset(Biofilm2_par.R2vsR3,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
FAs_mult.R2vsR3<-sqrt(Biofilm_MULT.R2vsR3)

bd <- betadisper(vegdist(FAs_mult.R2vsR3), Biofilm2_par.R2vsR3$Run)
permutest(bd)

ad <- adonis2(FAs_mult.R2vsR3 ~ Biofilm2_par.R2vsR3$Run)
ad

# NMDS

#function to check for number of axis in NMDS
#NMDS is repeated 10 times for each dimension
#check for the influence of the random initial configurations
# x must be a data-object which can be coerced into a matrix
# max is the maximum number of dimensions
# dist_meas is the distance measure
par(mfrow=c(1,1))
scree_values<-function(x,max,dist_meas)
{
  xx<-as.matrix(x)
  scree.points = NULL
  scree.temp = 1
  for(i in 1:max)
  {
    sol.mds = NULL
    sol.mds <- replicate(10, metaMDS(xx, k=i, autotransform = FALSE, trymax=30, distance=dist_meas)$stress,
                         simplify=TRUE)
    scree.points<-append(scree.points,sol.mds)
  }
  return(scree.points)
}

# calculate relationship between dimensions and stress
scree.res<-scree_values(FAs_mult, max=10, dist_meas ="bray")

# plot dimensions vs stress
par(cex=1.5,las=1,xpd=FALSE)
plot_vec <- as.vector(sapply(1:(length(scree.res)/10), function(x) rep(x,10), simplify = "vector" ))

plot(plot_vec,scree.res,ylab = "Stress1",xlab = "dimensions")
lines(1:(length(scree.res)/10),as.vector((by(scree.res,plot_vec,mean))))
abline(h=.10,col="red")

#Selection of dimensions and Stress level (based and data transformation and resemblance metric)
FA_NMDS<-metaMDS(FAs_mult,k=2, autotransform = FALSE ,distance = "bray")
FA_NMDS$stress

#Fits environmental factors and vectors
colnames(FAs_mult)<-c("15:0","16:0","16:1n-7","17:0","18:0","18:1n-7","18:1n-9", "18:2n-6", "18:3n-3",  "18:3n-6",
                         "20:0","20:1n-9" ,"20:2n-6","20:3n-3","20:4n-6","20:5n-3","22:0","22:6n-3","23:0","24:0")
FA_variables.SAFAs<-envfit(FA_NMDS, subset(FAs_mult,select = c("15:0","16:0","17:0","18:0","20:0","22:0","23:0","24:0"))
                              ,permutations = 999, na.rm = TRUE)
FA_variables.SAFAs

FA_variables.MUFAs<-envfit(FA_NMDS, subset(FAs_mult,select = c("16:1n-7","18:1n-7","18:1n-9","20:1n-9"))
                              ,permutations = 999, na.rm = TRUE)
FA_variables.MUFAs

FA_variables.PUFAs<-envfit(FA_NMDS, subset(FAs_mult,select = c("18:2n-6","18:3n-3","18:3n-6","20:2n-6","20:3n-3","20:4n-6","20:5n-3","22:6n-3"))
                              ,permutations = 999, na.rm = TRUE)
FA_variables.PUFAs

#plot Shepard diagram (Linear R^2 explain variation of regression of observed distances against ordination distances)
stressplot(FA_NMDS)

# NMDS Plot

par(mar=c(4.6,4.6,2.1,2.1),xpd=TRUE)
plotdf <- data.frame(FA_NMDS$points, Treatments)

points <- c(rep(21,2),rep(22,3),rep(24,3),rep(21,3),rep(22,3),rep(24,3))
# symbols for colonization phases: 21 = R1, 22 = R2, 24 = R3
color<-c(rep("black",8),rep("black",9))
fill_color<-c(rep("white",8),rep("grey50",9))

plot(c(0,1),c(0,1),type="n",xaxs="i",yaxs="i",xlim=c(-.5,.4),ylim=c(-.3,.3),axes=FALSE,bty="l",xlab="",ylab="",
     las=1,cex.lab=1.2,cex=1.2,cex.axis=1.2,lwd=1.5)
points( plotdf$MDS1, plotdf$MDS2, col=color,bg=fill_color, cex = 1.2, pch=points)
#ordispider(FA_NMDS, plotdf$Treatments,label=FALSE,cex = 1)
#points(rev(tapply(plotdf$MDS1,plotdf$Treatments,mean)),rev(tapply(plotdf$MDS2,plotdf$Treatments,mean)),bg=rev(c("white","black")),pch=22,cex=2)
axis(side=2, at=c(-.30,-.20,-.10,.0,.10,.20,.30), labels=c("-0.30","-0.20","-0.10", "0.00","0.10","0.20","0.30"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
axis(side=1, at=c(-.50,-.40,-.30,-.20,-.10,.0,.10,.20,.30,.40), labels=c("-0.50","-0.40","-0.30","-0.20","-0.10", "0.00","0.10","0.20","0.30","0.40"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
text(-.60,.0,"NMDS2", cex=1.2, xpd=NA,srt=90)
text(-.05,-.36,"NMDS1", cex=1.2, xpd=NA,srt=0)
legend("bottomright","stress: 0.059",bty="n",cex=1.2)
ordiellipse(FA_NMDS, Treatments, col=c("grey80","black"),kind = "sd",conf=0.95, lwd=2,lty=c(1,6))
# Farben der Treatments: Control = 1. solid, Treatment = 6. twodash
plot(FA_variables.SAFAs,col="darkorchid3")
plot(FA_variables.MUFAs,col="blue")
plot(FA_variables.PUFAs,col="chartreuse4")


# Grafik f�r Verteidigung

# NMDS Plot

par(mar=c(4.6,4.6,2.1,2.1),xpd=TRUE)
plotdf <- data.frame(FA_NMDS$points, Treatments)

color<-c(rep("black",8),rep("black",9))
fill_color<-c(rep("cornflowerblue",8),rep("orange",9))

plot(c(0,1),c(0,1),type="n",xaxs="i",yaxs="i",xlim=c(-.6,.3),ylim=c(-.2,.2),axes=FALSE,bty="l",xlab="",ylab="",
     las=1,cex.lab=1.2,cex=1.2,cex.axis=1.2,lwd=1.5)
points( plotdf$MDS1, plotdf$MDS2, col=color,bg=fill_color, cex = 1.2, pch=22)
ordispider(FA_NMDS, plotdf$Treatments,label=FALSE,cex = 1)
points(rev(tapply(plotdf$MDS1,plotdf$Treatments,mean)),rev(tapply(plotdf$MDS2,plotdf$Treatments,mean)),bg=rev(c("cornflowerblue","orange")),pch=22,cex=2)
axis(side=2, at=c(-.2,-.1,.0,.10,.2), labels=c("-0.20","-0.10", "0.00","0.10","0.20"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
axis(side=1, at=c(-.6,-.3,.0,.3), labels=c("-0.60","-0.30", "0.00","0.30"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
text(-.825,.0,"NMDS2", cex=1.2, xpd=NA,srt=90)
text(-.15,-.30,"NMDS1", cex=1.2, xpd=NA,srt=0)

# 6 x 7


data.scores = as.data.frame(scores(FA_NMDS))
data.scores$Treatment = Treatments

SAFAs_coord_cont = as.data.frame(scores(FA_variables.SAFAs, "vectors")) * ordiArrowMul(FA_variables.SAFAs)
MUFAs_coord_cont = as.data.frame(scores(FA_variables.MUFAs, "vectors")) * ordiArrowMul(FA_variables.MUFAs)
PUFAs_coord_cont = as.data.frame(scores(FA_variables.PUFAs, "vectors")) * ordiArrowMul(FA_variables.PUFAs)

library(ggplot2)
library(ggrepel)
ggplot(data = data.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_point(data = data.scores, size = 7,shape=c(rep(21,2),rep(22,3),rep(24,3),rep(21,3),rep(22,3),rep(24,3)),
             fill=c(rep("white",8),rep("grey50",9)), color="black",stroke = 1.5) +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = SAFAs_coord_cont, size =2, alpha = 0.5, colour = "darkorange") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = MUFAs_coord_cont, size =2, alpha = 0.5, colour = "deepskyblue3") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = PUFAs_coord_cont, size =2, alpha = 0.5, colour = "chartreuse3") +
  geom_text(data = SAFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(SAFAs_coord_cont)) +
  geom_text(data = MUFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(MUFAs_coord_cont)) +
  geom_text_repel(data = PUFAs_coord_cont, aes(x = NMDS1, y = NMDS2),
                  box.padding = 1.5, direction= "both", segment.size = 2, segment.color = "chartreuse3",
                  nudge_x = c(-.01,-.01,.01,.01,-.05,-.05,-.01,.01),
                  alpha = 0.5, size =7.5, colour = "black", fontface = "bold", label = row.names(PUFAs_coord_cont)) +
  theme(axis.title = element_text(size = 20, colour = "black"),
        panel.background = element_blank(), panel.border = element_rect(fill = NA, colour = "black"),
        axis.ticks = element_blank(), axis.text = element_blank())


#### Relative


total_FAs_rel$ID<- with(total_FAs_rel, paste0(Run, Treatment, Replicate))

total_FAs_rel_par<-merge(total_FAs_rel, Parameters[, with = F],  by = "ID")
total_FAs_rel_par<-total_FAs_rel_par[order(Treatment),]

total_FAs_rel_MULT<-subset(total_FAs_rel_par,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
total_FAs_rel_MULT<-total_FAs_rel_MULT/100
relFAs_mult<-sqrt(total_FAs_rel_MULT)

# Outlier detection
aq.plot(relFAs_mult[,-c(11,12,13,14,17)])

# Assumption for applying PERMANOVA (=> gleiche Streuung innerhalb der Gruppen)
bd <- betadisper(vegdist(relFAs_mult), total_FAs_rel_par$Treatment)
permutest(bd)

bd <- betadisper(vegdist(relFAs_mult), total_FAs_rel_par$Run)
permutest(bd)

ad <- adonis2(relFAs_mult ~ total_FAs_rel_par$Treatment * total_FAs_rel_par$Run)
ad # sig.


# SIMPER (similarity percentage analysis)
simper <- simper(relFAs_mult, Treatments)
summary(simper)


# Colonization phases
# Phase 1 vs phase 2
total_FAs_rel_par.R1vsR2<-subset(total_FAs_rel_par, Run %in% c("R1","R2"))
total_FAs_relMULT.R1vsR2<-subset(total_FAs_rel_par.R1vsR2,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
relFAs_mult.R1vsR2<-sqrt(total_FAs_relMULT.R1vsR2)

bd <- betadisper(vegdist(relFAs_mult.R1vsR2), total_FAs_rel_par.R1vsR2$Run)
permutest(bd)


ad <- adonis2(relFAs_mult.R1vsR2 ~ total_FAs_rel_par.R1vsR2$Run)
ad

# Phase 1 vs phase 3
total_FAs_rel_par.R1vsR3<-subset(total_FAs_rel_par, Run %in% c("R1","R3"))
total_FAs_rel_MULT.R1vsR3<-subset(total_FAs_rel_par.R1vsR3,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
relFAs_mult.R1vsR3<-sqrt(total_FAs_rel_MULT.R1vsR3)

bd <- betadisper(vegdist(relFAs_mult.R1vsR3), total_FAs_rel_par.R1vsR3$Run)
permutest(bd)

ad <- adonis2(relFAs_mult.R1vsR3 ~ total_FAs_rel_par.R1vsR3$Run)
ad

# Phase 2 vs phase 3
total_FAs_rel_par.R2vsR3<-subset(total_FAs_rel_par, Run %in% c("R2","R3"))
total_FAs_rel_MULT.R2vsR3<-subset(total_FAs_rel_par.R2vsR3,select=-c(ID,RUNINFO,Run, Treatment,Replicate,Concentration,pH,O2,Conductivity,Velocity,Illuminance,PhotoActRad))
relFAs_mult.R2vsR3<-sqrt(total_FAs_rel_MULT.R2vsR3)

bd <- betadisper(vegdist(relFAs_mult.R2vsR3), total_FAs_rel_par.R2vsR3$Run)
permutest(bd)

ad <- adonis2(relFAs_mult.R2vsR3 ~ total_FAs_rel_par.R2vsR3$Run)
ad

# NMDS

#function to check for number of axis in NMDS
#NMDS is repeated 10 times for each dimension
#check for the influence of the random initial configurations
# x must be a data-object which can be coerced into a matrix
# max is the maximum number of dimensions
# dist_meas is the distance measure
par(mfrow=c(1,1))
scree_values<-function(x,max,dist_meas)
{
  xx<-as.matrix(x)
  scree.points = NULL
  scree.temp = 1
  for(i in 1:max)
  {
    sol.mds = NULL
    sol.mds <- replicate(10, metaMDS(xx, k=i, autotransform = FALSE, trymax=30, distance=dist_meas)$stress,
                         simplify=TRUE)
    scree.points<-append(scree.points,sol.mds)
  }
  return(scree.points)
}

# calculate relationship between dimensions and stress
scree.res<-scree_values(relFAs_mult, max=10, dist_meas ="bray")

# plot dimensions vs stress
par(cex=1.5,las=1,xpd=FALSE)
plot_vec <- as.vector(sapply(1:(length(scree.res)/10), function(x) rep(x,10), simplify = "vector" ))

plot(plot_vec,scree.res,ylab = "Stress1",xlab = "dimensions")
lines(1:(length(scree.res)/10),as.vector((by(scree.res,plot_vec,mean))))
abline(h=.10,col="red")

#Selection of dimensions and Stress level (based and data transformation and resemblance metric)
relFA_NMDS<-metaMDS(relFAs_mult,k=2, autotransform = FALSE ,distance = "bray")
relFA_NMDS$stress

#plot Shepard diagram (Linear R^2 explain variation of regression of observed distances against ordination distances)
stressplot(relFA_NMDS)

#Fits environmental factors and vectors
colnames(relFAs_mult)<-c("15:0","16:0","16:1n-7","17:0","18:0","18:1n-7","18:1n-9", "18:2n-6", "18:3n-3",  "18:3n-6",
                         "20:0","20:1n-9" ,"20:2n-6","20:3n-3","20:4n-6","20:5n-3","22:0","22:6n-3","23:0","24:0")
relFA_variables.SAFAs<-envfit(relFA_NMDS, subset(relFAs_mult,select = c("15:0","16:0","17:0","18:0","20:0","22:0","23:0","24:0"))
                              ,permutations = 999, na.rm = TRUE)
relFA_variables.SAFAs

relFA_variables.MUFAs<-envfit(relFA_NMDS, subset(relFAs_mult,select = c("16:1n-7","18:1n-7","18:1n-9","20:1n-9"))
                              ,permutations = 999, na.rm = TRUE)
relFA_variables.MUFAs

relFA_variables.PUFAs<-envfit(relFA_NMDS, subset(relFAs_mult,select = c("18:2n-6","18:3n-3","18:3n-6","20:2n-6","20:3n-3","20:4n-6","20:5n-3","22:6n-3"))
                              ,permutations = 999, na.rm = TRUE)
relFA_variables.PUFAs

# NMDS Plot
par(mar=c(4.6,4.6,2.1,2.1),xpd=TRUE)
plotdf <- data.frame(relFA_NMDS$points, Treatments)

points <- c(rep(21,2),rep(22,3),rep(24,3),rep(21,3),rep(22,3),rep(24,3))
# symbols for colonization phases: 21 = R1, 22 = R2, 24 = R3
color<-c(rep("black",8),rep("black",9))
fill_color<-c(rep("white",8),rep("grey50",9))

plot(c(0,1),c(0,1),type="n",xaxs="i",yaxs="i",xlim=c(-.3,.3),ylim=c(-.3,.3),axes=FALSE,bty="l",xlab="",ylab="",
     las=1,cex.lab=1.2,cex=1.2,cex.axis=1.2,lwd=1.5)
points( plotdf$MDS1, plotdf$MDS2, col=color,bg=fill_color, cex = 1.2, pch=points)
#ordispider(relFA_NMDS, plotdf$Treatments,label=FALSE,cex = 1)
#points(rev(tapply(plotdf$MDS1,plotdf$Treatments,mean)),rev(tapply(plotdf$MDS2,plotdf$Treatments,mean)),bg=rev(c("white","black")),pch=22,cex=2)
axis(side=2, at=c(-.20,-.10,.0,.10,.20), labels=c("-0.20","-0.10", "0.00","0.10","0.20"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
axis(side=1, at=c(-.30,-.20,-.10,.0,.10,.20,.30), labels=c("-0.30","-0.20","-0.10", "0.00","0.10","0.20","0.30"), las=1,cex.axis=1.2,cex.lab=1.2,lwd=1.5)
text(-.60,.0,"NMDS2", cex=1.2, xpd=NA,srt=90)
text(-.05,-.36,"NMDS1", cex=1.2, xpd=NA,srt=0)
legend("bottomright","stress: 0.140",bty="n",cex=1.2)
ordiellipse(relFA_NMDS, Treatments, col=c("grey80","black"),kind = "sd",conf=0.95, lwd=2,lty=c(1,6))
plot(relFA_variables.SAFAs,col="darkorchid3",cex=1.2)
plot(relFA_variables.MUFAs,col="blue",cex=1.2)
plot(relFA_variables.PUFAs,col="chartreuse4",cex=1.2)

data.scores = as.data.frame(scores(relFA_NMDS))
data.scores$Treatment = Treatments

relSAFAs_coord_cont = as.data.frame(scores(relFA_variables.SAFAs, "vectors")) * ordiArrowMul(relFA_variables.SAFAs)
relMUFAs_coord_cont = as.data.frame(scores(relFA_variables.MUFAs, "vectors")) * ordiArrowMul(relFA_variables.MUFAs)
relPUFAs_coord_cont = as.data.frame(scores(relFA_variables.PUFAs, "vectors")) * ordiArrowMul(relFA_variables.PUFAs)

ggplot(data = data.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_point(data = data.scores, size = 7,shape=c(rep(21,2),rep(22,3),rep(24,3),rep(21,3),rep(22,3),rep(24,3)),
             fill=c(rep("white",8),rep("grey50",9)), color="black",stroke = 1.5) +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = relSAFAs_coord_cont, size =2, alpha = 0.5, colour = "darkorange") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = relMUFAs_coord_cont, size =2, alpha = 0.5, colour = "deepskyblue3") +
  geom_segment(aes(x = 0, y = 0, xend = NMDS1, yend = NMDS2),data = relPUFAs_coord_cont, size =2, alpha = 0.5, colour = "chartreuse3") +
  geom_text(data = relSAFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(relSAFAs_coord_cont)) +
  geom_text(data = relMUFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(relMUFAs_coord_cont)) +
  geom_text(data = relPUFAs_coord_cont, aes(x = NMDS1, y = NMDS2), alpha = 0.5, size =7.5, colour = "black", fontface = "bold",
            label = row.names(relPUFAs_coord_cont)) +
  theme(axis.title = element_text(size = 20, colour = "black"),
        panel.background = element_blank(), panel.border = element_rect(fill = NA, colour = "black"),
        axis.ticks = element_blank(), axis.text = element_blank())

# Farben der Treatments: Control = 1. solid, Treatment = 6. twodash


#### PCA / RDA

# panel.cor<-function(x,y,digits=2,prefix="",cex.cor)
# {
# usr<-par("usr"); on.exit(par(usr))
# par(usr=c(0,1,0,1))
# r<-abs(cor(x,y, use="complete.obs"))
# txt<-format(c(r,0.123456789),digits=digits)[1]
# txt<-paste(prefix,txt,sep="")
# if(missing(cex.cor)) cex<-0.8/strwidth(txt)
#
# test<-cor.test(x,y)
# Signif<-symnum(test$p.value,corr=FALSE,na=FALSE,
#                cutpoints = c(0,0.05,0.1,1),
#                symbols = c("*","."," "))
# text(0.5,0.5,txt,cex=cex * r)
# text(.8,.8,Signif,cex=cex,col=2)
#
# }
#
# pairs(Parameters_mult,lower.panel = panel.smooth,upper.panel = panel.cor)
#
# # Variance inflation factor (VIF)
# library(faraway)
# sort(vif(Parameters_mult))
# # Als Faustregel gilt, dass in einem linearen Modell die VIF-Werte der unabh�ngigen Variablen kleiner als 10 sein sollen,
# # um Probleme mit der Interpretierbarkeit der Koeffizienten zu vermeiden (Borcard et al., 2011).
#
# # Gradient length
# decorana(FAs_mult)
# # gives the average standard deviation
# # linear analyses are presumably ok for SD up to 2-3 (< 2 RDA is appropriate)
#
# # Check whether Hellinger transformation decreases gradient length (caution: interpretation is more difficult)
# Parameters_mult_hel<-decostand(FAs_mult,"hellinger")
# decorana(Parameters_mult_hel)
#
# # RDA
#
# RDA_final<-rda(FAs_mult~.,data=Parameters_mult,scale=TRUE)
# summary(RDA_final)
#
# # Extraction of canonical coefficients from RDA object
# coef(RDA_final)
#
# # Global test of the RDA result (significance of the model)
# set.seed(111)
# anova.cca(RDA_final,step=1000)
#
# # Test of all canonical axes
# set.seed(111)
# anova.cca(RDA_final,by="axis",step=1000)
#
# par(mfrow=c(1,2))
# plot(RDA_final,scaling=1,main="Triplot RDA scaling 1 - wa scores")
# RDA.sc<-scores(RDA_final,choice=1:2,scaling=1,display="sp")
# arrows(0,0,RDA.sc[,1],RDA.sc[,2],length=0,lty=1,col="red" )
#
# # Correlation triplot
# plot(RDA_final,main="Triplot RDA scaling 2 -wa scores")
# RDA2.sc<-scores(RDA_final,choices = 1:2,display = "sp")
# arrows(0,0,RDA2.sc[,1],RDA2.sc[,2],length=0,lty=1,col="red" )
